
export enum ListingType {
  ACTIVITY = 'ACTIVITY',
  RENT = 'RENT',
  TRIP = 'TRIP'
}

export enum SportCategory {
  WATER = 'WATER',
  LAND = 'LAND',
  SNOW = 'SNOW',
  AIR = 'AIR'
}

export enum DifficultyLevel {
  BEGINNER = 'BEGINNER',
  INTERMEDIATE = 'INTERMEDIATE',
  ADVANCED = 'ADVANCED',
  EXPERT = 'EXPERT',
  PRO = 'PRO'
}

export enum BookingStatus {
  PENDING = 'PENDING',
  CONFIRMED = 'CONFIRMED',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED'
}

// Geographically strict types
export interface GeoLocation {
  continent: string;
  country: string;
  city: string;
  lat: number;
  lng: number;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
  visitedLocation?: string;
}

export interface Listing {
  id: string;
  title: string;
  type: ListingType;
  category: SportCategory;
  sport: string; // e.g., "Kitesurf", "MTB"
  price: number;
  currency: string;
  rating: number;
  reviewCount: number;
  location: GeoLocation;
  images: string[];
  providerId: string;
  providerName: string;
  isVerified: boolean;
  status: 'ACTIVE' | 'PENDING_APPROVAL' | 'SUSPENDED'; // Admin flow
  
  // Specific details based on type
  difficulty?: string; 
  duration?: string; 
  
  // Rent specific
  availableSizes?: string[];
  inventoryCount?: number;
  
  // Trip specific
  itinerary?: { day: number; title: string; description: string }[];
  startDate?: string;
  endDate?: string;
  
  description: string;
}

export interface Booking {
  id: string;
  listingId: string;
  listingTitle: string;
  listingImage: string;
  userId: string;
  providerId: string;
  date: string; // ISO Date
  endDate?: string;
  totalPrice: number;
  currency: string;
  status: BookingStatus;
  guests: number;
  selectedSize?: string; // For Rentals
  
  // Mission Control Details
  meetingPoint?: {
    name: string;
    address: string;
    lat: number;
    lng: number;
    instructions: string;
  };
  packingList?: { item: string; required: boolean; checked?: boolean }[];
  ticketQr?: string; // URL to QR image
  instructor?: {
    name: string;
    phone: string;
    avatar: string;
    whatsapp?: string;
  };
  timeline?: { time: string; activity: string; icon?: string }[];
}

export interface User {
  id: string;
  name: string;
  role: 'USER' | 'PROVIDER' | 'ADMIN';
  avatar: string;
}

export interface Story {
  id: string;
  title: string;
  image: string;
  author: string;
  likes: number;
  views: number;
  category: string;
}

export interface ProviderProfile {
  id: string;
  name: string;
  logo: string;
  isVerified: boolean;
  location: string;
  sports: string[];
  bio: string;
  socials: { web?: string; instagram?: string; youtube?: string };
  stats: { views: number; reviews: number; trips: number };
  stories: Story[];
  reviews: Review[];
}

export interface CityDetail {
  id: string;
  name: string;
  country: string;
  continent: string;
  description?: string;
  heroImage?: string;
  images?: string[];
  population?: number;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export interface SportDirectoryItem {
  slug: string;
  name: string;
  image: string;
  category: SportCategory;
  description?: string;
}