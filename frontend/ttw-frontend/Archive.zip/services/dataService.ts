// REAL API SERVICE
// Connects frontend to Django backend

import { Listing, Booking } from "../types";

const API_URL = "http://127.0.0.1:8000/api";

// -------------------------------
// LISTINGS
// -------------------------------

export const getListings = async (filters: any = {}): Promise<Listing[]> => {
  const url = new URL(`${API_URL}/listings/`);

  Object.keys(filters).forEach((key) => {
    if (filters[key]) url.searchParams.append(key, filters[key]);
  });

  const res = await fetch(url.toString());
  if (!res.ok) throw new Error("Error fetching listings");

  return await res.json();
};

export const getListingById = async (id: string): Promise<Listing> => {
  const res = await fetch(`${API_URL}/listings/${id}/`);
  if (!res.ok) throw new Error("Listing not found");
  return await res.json();
};

// Provider creates listing
export const createListing = async (listingData: any): Promise<boolean> => {
  const res = await fetch(`${API_URL}/listings/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(listingData),
  });

  return res.ok;
};

// -------------------------------
// BOOKINGS / CHECKOUT
// -------------------------------

export const createBooking = async (bookingData: any): Promise<string> => {
  const res = await fetch(`${API_URL}/payments/checkout/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(bookingData),
  });

  if (!res.ok) throw new Error("Booking creation failed");
  const data = await res.json();
  return data.bookingId;
};

export const getUserBookings = async (userId: string): Promise<Booking[]> => {
  const res = await fetch(`${API_URL}/bookings/?user=${userId}`);
  if (!res.ok) throw new Error("Error loading user bookings");
  return await res.json();
};

export const getProviderBookings = async (providerId: string): Promise<Booking[]> => {
  const res = await fetch(`${API_URL}/bookings/?provider=${providerId}`);
  if (!res.ok) throw new Error("Error loading provider bookings");
  return await res.json();
};

// -------------------------------
// GEO DATA
// -------------------------------

export const getCities = async () => {
  const res = await fetch(`${API_URL}/cities/`);
  return res.json();
};

export const getCityDetails = async (cityId: string) => {
  const res = await fetch(`${API_URL}/cities/${cityId}/`);
  return res.json();
};

export const getCountries = async () => {
  const res = await fetch(`${API_URL}/countries/`);
  return res.json();
};

export const getCountryDetails = async (countryId: string) => {
  const res = await fetch(`${API_URL}/countries/${countryId}/`);
  return res.json();
};

export const getContinents = async () => {
  const res = await fetch(`${API_URL}/continents/`);
  return res.json();
};

export const getContinentDetails = async (continentId: string) => {
  const res = await fetch(`${API_URL}/continents/${continentId}/`);
  return res.json();
};

// -------------------------------
// DESTINATIONS (CONTINENTS / COUNTRIES)
// -------------------------------

export interface CountryData {
  name: string;
  image: string;
  count: number;
  continent: string;
}

// TEMP: until backend provides real endpoints
// Gets list of countries available inside a continent
export const getCountriesByContinent = async (
  continent: string
): Promise<CountryData[]> => {
  // TEMP mock fallback
  await new Promise((resolve) => setTimeout(resolve, 300));

  // Filter listings by continent
  const res = await getListings({ continent });

  const countries: Record<string, CountryData> = {};

  res.forEach((l) => {
    const c = l.location.country;
    if (!countries[c]) {
      countries[c] = {
        name: c,
        image: l.images[0],
        count: 0,
        continent: l.location.continent,
      };
    }
    countries[c].count++;
  });

  return Object.values(countries);
};

// TEMP: Signature trips per continent
export const getSignatureTrips = async (
  continent: string
): Promise<Listing[]> => {
  await new Promise((resolve) => setTimeout(resolve, 300));

  const res = await getListings({ continent, type: "TRIP" });

  // If no trips exist, fallback to all trips (for UI)
  if (res.length === 0) {
    return await getListings({ type: "TRIP" });
  }

  return res;
};

// ---------------------------------------
// GEO – Get list of available countries
// ---------------------------------------
export const getAvailableCountries = async (): Promise<any[]> => {
    const res = await fetch(`${API_URL}/countries/`);
    if (!res.ok) throw new Error("Error fetching countries");
    return await res.json();
};

// ---------------------------------------
// LOGIN
// ---------------------------------------
export const login = async (email: string, role: string) => {
  await new Promise(resolve => setTimeout(resolve, 800));
  return {
    id: 'u-' + Math.random().toString(36).substr(2, 9),
    name: 'Demo User',
    role: role as 'USER' | 'PROVIDER' | 'ADMIN',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix'
  };
};

export const updateProviderOnboarding = async (providerId: string, data: any): Promise<boolean> => {
  await new Promise(resolve => setTimeout(resolve, 500));  
  return true;
};

export const getProviderProfile = async (providerId: string) => {
  await new Promise((resolve) => setTimeout(resolve, 400));

  // Mock temporal (esta data ya la tienes en Gemini)
  return {
    id: providerId,
    name: "Modo Experto School",
    logo: "https://images.unsplash.com/photo-1541535650810-10d26f5c2ab3?auto=format&fit=crop&w=200&q=80",
    isVerified: true,
    location: "Viana do Castelo, Portugal",
    sports: ["Kitesurf", "Wingfoil", "Surf", "SUP"],
    bio: "At Modo Experto School, we believe that sports connect us to nature...",
    socials: {
      web: "www.thatravelwild.com/modoexpertoschool",
      instagram: "#",
      youtube: "#",
    },
    stats: {
      views: 147,
      reviews: 11,
      trips: 3,
    },
    stories: [],
    reviews: [],
  };
};

// -------------------------------
// SPORTS DIRECTORY
// -------------------------------

export const getSportsDirectory = async () => {
  const res = await fetch(`${API_URL}/sports/`);
  if (!res.ok) throw new Error("Error fetching sports directory");
  return await res.json();
};

// -------------------------------
// SPORTS – LANDING PAGE DATA
// -------------------------------

// Type returned by the sport landing endpoint
export interface SportLandingData {
  name: string;
  description: string;
  heroImage: string;
  totalListings: number;
  popularCountries: string[];
}

// Fetch landing details for a sport
export const getSportLandingDetails = async (
  sportSlug: string
): Promise<SportLandingData> => {
  const res = await fetch(`${API_URL}/sports/${sportSlug}/`);
  if (!res.ok) throw new Error("Error fetching sport landing data");
  return await res.json();
};

// Fetch top schools (premium partners) for a sport
export const getTopSchoolsForSport = async (sportSlug: string) => {
  const res = await fetch(`${API_URL}/schools/top/?sport=${sportSlug}`);
  if (!res.ok) throw new Error("Error fetching top schools for sport");
  return await res.json();
};

// -------------------------------
// SINGLE BOOKING (UserBookingDetail)
// -------------------------------
export const getUserBookingById = async (bookingId: string): Promise<Booking> => {
  const res = await fetch(`${API_URL}/bookings/${bookingId}/`);
  if (!res.ok) throw new Error("Booking not found");
  return await res.json();
};

// DASHBOARD FLOW – Pending Listings for Admin
export const getPendingListings = async () => {
  const res = await fetch(`${API_URL}/listings/?status=PENDING_APPROVAL`);
  if (!res.ok) throw new Error("Error fetching pending listings");
  return await res.json();
};

// Approve a listing
export const approveListing = async (id: string) => {
  const res = await fetch(`${API_URL}/listings/${id}/approve/`, {
    method: "POST",
  });
  if (!res.ok) throw new Error("Failed to approve listing");
  return true;
};