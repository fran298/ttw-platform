import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Explore from './pages/Explore';
import Detail from './pages/Detail';
import Dashboard from './pages/Dashboard';
import Checkout from './pages/Checkout';
import ContinentLanding from './pages/ContinentLanding';
import DestinationsIndex from './pages/DestinationsIndex';
import CityLanding from './pages/CityLanding';
import DestinationLanding from './pages/DestinationLanding';
import ProviderProfilePage from './pages/ProviderProfile';
import SignupUser from './pages/SignupUser';
import SignupProvider from './pages/SignupProvider';
import SignupSelection from './pages/SignupSelection';
import SportsIndex from './pages/SportsIndex';
import SportLanding from './pages/SportLanding';
import Login from './pages/Login';
import ProviderOnboarding from './pages/ProviderOnboarding';
import UserBookingDetail from './pages/UserBookingDetail';
import Footer from "./pages/Footer";
import { Globe, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';
import BecomeMember from './pages/BecomeMember';

const App: React.FC = () => {
  const [userRole, setUserRole] = useState<'USER' | 'PROVIDER' | 'ADMIN'>('USER');

  const location = useLocation();
  const hideNavbar =
    location.pathname.startsWith('/login') ||
    location.pathname.startsWith('/signup') ||
    location.pathname.startsWith('/onboarding');

  const hideFooter = hideNavbar;

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 flex flex-col">

      {!hideNavbar && (
        <Navbar userRole={userRole} setUserRole={setUserRole} />
      )}

      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/instructors" element={<div className="p-10 text-center text-xl">Instructors landing coming soon</div>} />
          <Route path="/membership" element={<BecomeMember />} />
          <Route path="/contact" element={<div className="p-10 text-center text-xl">Contact page coming soon</div>} />

          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignupSelection />} />

          {/* Geography */}
          <Route path="/destinations" element={<DestinationsIndex />} />
          <Route path="/continent/:continentId" element={<ContinentLanding />} />
          <Route path="/destination/:geoId" element={<DestinationLanding />} />
          <Route path="/city/:cityId" element={<CityLanding />} />

          {/* Detail */}
          <Route path="/activity/:id" element={<Detail />} />
          <Route path="/rent/:id" element={<Detail />} />
          <Route path="/trip/:id" element={<Detail />} />

          {/* Provider */}
          <Route path="/provider/:providerId" element={<ProviderProfilePage />} />

          {/* Commerce */}
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/booking/:bookingId" element={<UserBookingDetail />} />

          {/* Auth */}
          <Route path="/signup/user" element={<SignupUser />} />
          <Route path="/signup/provider" element={<SignupProvider />} />
          <Route path="/onboarding" element={<ProviderOnboarding />} />
          
          {/* Sports Directory */}
          <Route path="/sports" element={<SportsIndex />} />
          <Route path="/sport/:sportSlug" element={<SportLanding />} />

          {/* Dashboard */}
          <Route path="/dashboard" element={<Dashboard role={userRole} />} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      {!hideFooter && <Footer />}
    </div>
  );
};

// Necesario cuando usas useLocation fuera de BrowserRouter/HashRouter
const AppWrapper = () => (
  <HashRouter>
    <App />
  </HashRouter>
);

export default AppWrapper;