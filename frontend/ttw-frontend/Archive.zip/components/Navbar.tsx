import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, User, Globe } from 'lucide-react';

interface NavbarProps {
  userRole: 'USER' | 'PROVIDER' | 'ADMIN';
  setUserRole: (role: 'USER' | 'PROVIDER' | 'ADMIN') => void;
}

const Navbar: React.FC<NavbarProps> = ({ userRole, setUserRole }) => {
  const location = useLocation();

  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center group">
            <img 
              src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763998121/The-Travel-Wild-_Logo-fondo-transparente_tvxme0.png"
              alt="The Travel Wild Logo"
              className="h-32 w-auto mr-4 object-contain"
            />
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex space-x-8 items-center">
            <Link to="/" className="text-sm font-semibold text-gray-800 hover:text-brand-600">
              Home
            </Link>
            <Link to="/sports" className="text-sm font-semibold text-gray-600 hover:text-brand-600">
              Sports
            </Link>
            <Link to="/destinations" className="text-sm font-semibold text-gray-600 hover:text-brand-600">
              Destination
            </Link>
            <Link to="/instructors" className="text-sm font-semibold text-gray-600 hover:text-brand-600">
              Instructors
            </Link>
            <Link to="/membership" className="text-sm font-semibold text-gray-600 hover:text-brand-600">
              Become Member
            </Link>
            <Link to="/contact" className="text-sm font-semibold text-gray-600 hover:text-brand-600">
              Contact
            </Link>
          </div>

          {/* Right Side: Role & Auth */}
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-3">
                <button className="px-5 py-2 text-sm font-bold text-[#132b5b] border border-[#132b5b] rounded-full hover:bg-[#132b5b]/10 transition-colors">
                    Sign up
                </button>
                <button className="px-5 py-2 text-sm font-bold text-white bg-[#132b5b] rounded-full hover:bg-[#0f234a] transition-colors shadow-lg shadow-gray-200">
                    Login
                </button>
            </div>
            
            {/* Mobile Menu Button */}
            <div className="lg:hidden p-2">
                <Menu className="w-6 h-6 text-gray-600" />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;