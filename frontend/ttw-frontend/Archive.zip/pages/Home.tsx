import React from 'react';
import { Link } from 'react-router-dom';
import { Search, ChevronRight, ChevronLeft, ArrowRight } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col w-full font-sans">
      
      {/* HERO SECTION */}
      <section className="
  relative
  h-[58vh]        /* mobile */
  md:h-[45vh]     /* ipad mini, ipad air, ipad pro 11 */
  lg:h-[29vh]     /* ipad pro 12.9 */
  xl:h-[58vh]     /* desktop */
  2xl:h-[58vh]    /* desktop large */
  w-full
">
        <div className="absolute inset-0">
            <img 
                src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763502872/Foto-principal_pevang.jpg"
                alt="The Travel Wild Hero"
                className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/10"></div>
        </div>
        
        <div className="relative z-10 h-full flex flex-col items-center text-center px-4 pt-20">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg max-w-4xl leading-tight">
                Find your next Wild Adventure
            </h1>
            <p className="text-lg md:text-xl text-gray-100 mb-12 font-medium drop-shadow-md">
                Discover extreme sports and destinations around the world
            </p>

            {/* Search Bar */}
            <div className="bg-white rounded-2xl p-1 pl-4 flex flex-col md:flex-row items-center shadow-2xl max-w-3xl w-full mx-auto mt-20 md:mt-32">
                <div className="flex-1 w-full md:w-auto border-b md:border-b-0 md:border-r border-gray-200 py-2 md:py-0 pr-4 relative">
                    <label className="block text-xs font-bold text-gray-800 ml-1">Where?</label>
                    <input 
                        type="text" 
                        placeholder="Anywhere" 
                        className="w-full p-1 text-gray-600 placeholder-gray-400 bg-transparent focus:outline-none text-sm"
                    />
                </div>
                <div className="flex-1 w-full md:w-auto border-b md:border-b-0 md:border-r border-gray-200 py-2 md:py-0 px-4 relative">
                    <label className="block text-xs font-bold text-gray-800 ml-1">When?</label>
                    <input 
                        type="text" 
                        placeholder="Whenever" 
                        className="w-full p-1 text-gray-600 placeholder-gray-400 bg-transparent focus:outline-none text-sm"
                    />
                </div>
                <button className="bg-[#132b5b] hover:bg-[#0f234b] text-white p-3 rounded-full transition-colors m-1 shadow-lg">
                    <Search className="w-5 h-5" />
                </button>
            </div>
        </div>
      </section>

      {/* SPORTS GRID SECTION */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full ">
        <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900">What extreme sport are you looking for?</h2>
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* MOBILE SLIDER: 4 sports visible per swipe */}
          <div className="flex overflow-x-auto snap-x gap-4 md:hidden pb-2 scrollbar-hide">
              {[
                  { name: 'Surf', img: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Scuba Diving', img: 'https://images.unsplash.com/photo-1682685797208-c741d5847803?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Snowboard', img: 'https://images.unsplash.com/photo-1565992441121-4367c2967103?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Sky', img: 'https://images.unsplash.com/photo-1529669851696-0d29c19e92c9?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Kitesurfing', img: 'https://images.unsplash.com/photo-1606636660801-0365a88356a5?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Paragliding', img: 'https://images.unsplash.com/photo-1516546453174-5e1098a4b4af?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Climbing', img: 'https://images.unsplash.com/photo-1522661067900-ab829854a57f?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Mountain Bike', img: 'https://images.unsplash.com/photo-1544183665-273a9c00550d?auto=format&fit=crop&w=500&q=80' },
              ].map((sport, idx) => (
                  <Link
                      to={`/explore?sport=${sport.name}`}
                      key={idx}
                      className="
                          group relative 
                          min-w-[45%]       
                          md:min-w-[25%]    
                          h-40 md:h-48 
                          rounded-xl overflow-hidden snap-center
                      "
                  >
                      <img 
                          src={sport.img} 
                          alt={sport.name} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                      <h3 className="absolute bottom-4 left-4 text-white font-bold text-lg drop-shadow-md">
                          {sport.name}
                      </h3>
                  </Link>
              ))}
          </div>

          {/* DESKTOP GRID */}
          <div className="hidden md:grid grid-cols-4 gap-4">
              {[
                  { name: 'Surf', img: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Scuba Diving', img: 'https://images.unsplash.com/photo-1682685797208-c741d5847803?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Snowboard', img: 'https://images.unsplash.com/photo-1565992441121-4367c2967103?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Sky', img: 'https://images.unsplash.com/photo-1529669851696-0d29c19e92c9?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Kitesurfing', img: 'https://images.unsplash.com/photo-1606636660801-0365a88356a5?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Paragliding', img: 'https://images.unsplash.com/photo-1516546453174-5e1098a4b4af?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Climbing', img: 'https://images.unsplash.com/photo-1522661067900-ab829854a57f?auto=format&fit=crop&w=500&q=80' },
                  { name: 'Mountain Bike', img: 'https://images.unsplash.com/photo-1544183665-273a9c00550d?auto=format&fit=crop&w=500&q=80' },
              ].map((sport, idx) => (
                  <Link
                      to={`/explore?sport=${sport.name}`}
                      key={idx}
                      className="group relative h-40 md:h-52 rounded-xl overflow-hidden cursor-pointer"
                  >
                      <img 
                          src={sport.img} 
                          alt={sport.name} 
                          className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                      <h3 className="absolute bottom-4 left-4 text-white font-bold text-xl drop-shadow-md">
                          {sport.name}
                      </h3>
                  </Link>
              ))}
          </div>
          <button className="hidden xl:flex absolute top-1/2 right-[-60px] transform -translate-y-1/2 w-10 h-10 rounded-full border border-gray-300 hover:bg-gray-100 transition-colors shadow bg-white items-center justify-center">
              <ChevronRight className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </section>


      {/* DESTINATIONS SECTION */}
      <section className="py-20 max-w-[100%] mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-extrabold text-center text-gray-900 mb-12">
          Top Wild Destinations
        </h2>

        {/* Carousel wrapper */}
        <div className="relative w-full overflow-hidden">
          <div className="flex transition-transform duration-500 ease-out" style={{ transform: `translateX(0%)` }}>
            {/* Slide */}
            <div className="min-w-full flex flex-col lg:flex-row gap-8 h-auto lg:h-[520px] w-full">
              {/* BIG ITEM */}
              <div className="relative rounded-3xl overflow-hidden group w-full md:w-[500px] h-[480px] flex-shrink-0">
                <img src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763409238/hiking_iguiku.jpg" alt="Chamonix" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <h3 className="absolute bottom-6 left-6 right-6 text-white font-bold text-xl leading-tight">Ski and Snowboard in Chamonix, France</h3>
              </div>

              {/* RIGHT GRID */}
              <div className="flex flex-col gap-4 w-full lg:w-[360px] lg:gap-6 lg:items-start">

                <div className="flex gap-6 w-full">
                  {/* Square */}
                  <div className="relative rounded-3xl overflow-hidden group w-full h-[200px] lg:w-[200px] lg:ml-[-1rem]">
                    <img src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763409238/hiking_iguiku.jpg" alt="Kite" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <h3 className="absolute bottom-3 left-3 text-white font-bold text-sm leading-tight">Kite in Cumbuco,<br/>Brazil</h3>
                  </div>

                  {/* Vertical */}
                  <div className="relative rounded-3xl overflow-hidden group w-full h-[270px] lg:w-[200px] lg:ml-[-0.5rem]">
                    <img src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763409238/hiking_iguiku.jpg" alt="Surf" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <h3 className="absolute bottom-3 left-3 text-white font-bold text-sm leading-tight">Surf in Peniche,<br/>Portugal</h3>
                  </div>
                </div>

                <div className="flex gap-6 w-full">
                  {/* Vertical */}
                  <div className="relative rounded-3xl overflow-hidden group w-full h-[270px] mt-[-4.3rem] lg:mt-[-5rem] lg:w-[200px] lg:ml-[-1rem]">
                    <img src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763409238/hiking_iguiku.jpg" alt="Zermatt" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <h3 className="absolute bottom-3 left-3 text-white font-bold text-sm leading-tight">Ski in Zermatt,<br/>Switzerland</h3>
                  </div>

                  {/* Square */}
                  <div className="relative rounded-3xl overflow-hidden group w-full h-[200px] lg:mt-[-0.5rem] lg:w-[200px] lg:ml-[-0.5rem]">
                    <img src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763409238/hiking_iguiku.jpg" alt="Dolomites" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <h3 className="absolute bottom-3 left-3 text-white font-bold text-sm leading-tight">Via Ferrata in<br/>Dolomites, Italy</h3>
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* Right arrow */}
          <button className="hidden md:flex absolute top-1/2 right-[-50px] transform -translate-y-1/2 w-12 h-12 rounded-full shadow-md bg-white items-center justify-center hover:bg-gray-100 transition">
            <ChevronRight className="w-6 h-6 text-gray-600" />
          </button>
        </div>
      </section>

      {/* WHO WE ARE */}
      <section className="relative w-auto">
        {/* BACKGROUND IMAGE visible on tablet & desktop */}
        <div className="hidden md:block absolute inset-0 w-full h-[400px] lg:h-[450px]">
          <img
            src="https://res.cloudinary.com/dmvlubzor/image/upload/v1763801588/WhoWeAre_o1uijj.jpg"
            alt="Who We Are Background"
            className="w-full h-full object-cover md:object-[-3rem] lg:object-center"
          />
        </div>

        {/* CONTENT OVER IMAGE */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-0 flex md:h-[400px] lg:h-[450px] items-center">
          <div className="flex flex-col items-center md:items-end justify-center md:justify-center bg-white/0 md:pr-8 w-full md:w-1/2 ml-auto">
            <h2 className="whitespace-nowrap md:text-3xl lg:text-4xl text-2xl lg:mr-[5rem] font-black text-gray-900 mb-6 text-center md:text-center md:mr-[3rem]">
              WHO WE ARE?
            </h2>
            <p className="md:text-lg lg:text-2xl font-semibold text-gray-800 leading-relaxed text-center md:text-center max-w-xl">
              We are the first platform Worldwide to bring together the extreme sports community with
              the objective to create transformative bridges between businesses, schools, instructors
              and people who share the same passion and love for nature and extreme sports.
            </p>
          </div>
        </div>


      </section>

      {/* BECOME A MEMBER */}
      <section className="py-20 md:py-10 bg-white">
        <div className="max-w-4xl mx-auto text-center mb-16 px-4">
            <h2 className="text-4xl font-extrabold text-gray-900 mb-4">Become a member</h2>
            <p className="text-lg text-gray-600">
                Our goal is to help people connect with the communities within each discipline, and we have a plan to make that happen.
            </p>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
                { title: 'Global visibility and new customers', desc: 'Showcase your school on TTW and position your profile as a leading authority in your field and city.', img: 'https://res.cloudinary.com/dmvlubzor/image/upload/v1764089053/Global-Visibility_fier6m.jpg' },
                { title: 'Build Reputation', desc: "Build trust with your clients by showcasing your organization's and your team's certifications.", img: 'https://res.cloudinary.com/dmvlubzor/image/upload/v1764089053/Build-Community_kylmdb.jpg' },
                { title: 'Become a reference in your community', desc: 'Get reviews from your students and improve your ranking to appear in the top positions for your disciplines and city.', img: 'https://res.cloudinary.com/dmvlubzor/image/upload/v1764089053/Became-Reference_m6ysni.jpg' },
            ].map((item, idx) => (
                <div key={idx} className="group relative h-96 rounded-2xl overflow-hidden cursor-pointer">
                    <img src={item.img} alt={item.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-transparent"></div>
                    <div className="absolute inset-0 flex flex-col justify-between p-8 text-center text-white">
                        <h3 className="font-bold text-xl mb-3 leading-tight mt-4">{item.title}</h3>
                        <p className="text-sm text-gray-200 opacity-100 transition-opacity duration-300 mb-6">
                            {item.desc}
                        </p>
                        <span className="text-xs font-bold tracking-widest uppercase border-b border-white/50 pb-1 inline-block mx-auto mt-auto">See More</span>
                    </div>
                </div>
            ))}
        </div>
      </section>

    </div>
  );
};

export default Home;