
import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, Mail } from 'lucide-react';

const SignupUser: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
        <Link to="/" className="flex items-center group mb-8">
            <div className="bg-brand-600 text-white p-2 rounded-full mr-2">
                <Globe className="w-8 h-8" />
            </div>
            <div className="flex flex-col leading-none">
                <span className="text-2xl font-black tracking-tight text-gray-800 uppercase">The Travel</span>
                <span className="text-2xl font-black tracking-tight text-brand-600 uppercase -mt-1">Wild</span>
            </div>
        </Link>

        <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Create your account</h2>

            <div className="space-y-3 mb-6">
                <button className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium text-gray-700">
                    <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5 mr-3" alt="Google" />
                    Continue with Google
                </button>
                <button className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium text-gray-700">
                     <img src="https://www.svgrepo.com/show/512317/apple-173.svg" className="w-5 h-5 mr-3" alt="Apple" />
                    Continue with Apple
                </button>
            </div>

            <div className="relative mb-6">
                <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">Or continue with email</span>
                </div>
            </div>

            <form className="space-y-4">
                <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Email</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Mail className="h-5 w-5 text-gray-400" />
                        </div>
                        <input type="email" className="w-full pl-10 border-gray-300 rounded-lg focus:ring-brand-500 focus:border-brand-500" placeholder="you@example.com" />
                    </div>
                </div>
                <div>
                     <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Password</label>
                     <input type="password" className="w-full border-gray-300 rounded-lg focus:ring-brand-500 focus:border-brand-500" placeholder="Create a strong password" />
                </div>
                
                <button className="w-full bg-brand-600 text-white py-3 rounded-lg font-bold hover:bg-brand-700 transition-colors">
                    Create Account
                </button>
            </form>

            <p className="mt-6 text-center text-xs text-gray-500">
                By clicking "Create Account", you agree to our <a href="#" className="underline">Terms</a> and <a href="#" className="underline">Privacy Policy</a>.
            </p>
        </div>
    </div>
  );
};

export default SignupUser;
