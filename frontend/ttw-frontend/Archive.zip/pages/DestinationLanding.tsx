
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getListings } from '../services/dataService';
import { Listing } from '../types';
import ListingCard from '../components/ListingCard';
import { MapPin, Star, ChevronLeft, ChevronRight, Search, ArrowRight } from 'lucide-react';

const DestinationLanding: React.FC = () => {
  const { geoId } = useParams<{ geoId: string }>();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  
  // State for the specific design elements
  const [activeTab, setActiveTab] = useState<string>('Surf'); // Default per mockup
  
  // Formatting
  const formattedName = geoId ? geoId.charAt(0).toUpperCase() + geoId.slice(1) : 'Destination';

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      // Try filtering by continent first, if empty try country
      let data = await getListings({ continent: formattedName });
      if (data.length === 0) {
         data = await getListings({ country: formattedName });
      }
      setListings(data);
      setLoading(false);
    };
    fetch();
  }, [geoId]);

  // Filter listings based on the active tab (mock logic for the design)
  // In a real app, this would query the API for that specific sport in that country
  const filteredListings = listings.filter(l => 
    activeTab === 'All' || l.sport.includes(activeTab) || l.category.includes(activeTab.toUpperCase())
  );
  
  // Fallback if no specific sport match found, show all so UI isn't empty
  const displayListings = filteredListings.length > 0 ? filteredListings : listings.slice(0, 3);

  // Mockup Tabs
  const sportsTabs = ['Surf', 'Kitesurf', 'Sailing', 'Wakeboard', 'Parasail'];

  // Mockup Images for the "Inspiration Grid" - dynamic based on active tab would be ideal, static for now to match layout
  const gridImages = [
    "https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=600&q=80",
    "https://images.unsplash.com/photo-1537551080512-320d8805f778?auto=format&fit=crop&w=600&q=80",
    "https://images.unsplash.com/photo-1520116468816-95b69f847357?auto=format&fit=crop&w=600&q=80",
    "https://images.unsplash.com/photo-1471922694854-ff1b63b20054?auto=format&fit=crop&w=600&q=80"
  ];

  return (
    <div className="min-h-screen bg-white font-sans">
      
      {/* 1. HERO SECTION (Matches Top of Mockup) */}
      <div className="relative h-[650px] w-full overflow-hidden group">
         <img 
            src={`https://source.unsplash.com/1600x900/?nature,landscape,${geoId}`} 
            alt={formattedName}
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
         />
         {/* Gradient Overlay */}
         <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30"></div>
         
         {/* Carousel Arrows (Visual Only) */}
         <button className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 backdrop-blur-md p-2 rounded-full text-white transition-colors">
            <ChevronLeft className="w-8 h-8" />
         </button>
         <button className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 backdrop-blur-md p-2 rounded-full text-white transition-colors">
            <ChevronRight className="w-8 h-8" />
         </button>

         {/* Content Overlay */}
         <div className="absolute inset-0 flex flex-col justify-center px-4 md:px-20 max-w-7xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg leading-tight">
                {formattedName}
            </h1>
            <p className="text-white/90 text-lg md:text-xl max-w-2xl mb-8 font-medium drop-shadow-md leading-relaxed">
                {formattedName} offers a variety of aquatic destinations, from famous beaches to hidden gems. 
                Perfect for surf, kitesurf and windsurf. Experience the wild side of nature.
            </p>

            {/* Search Pill (Matches Mockup) */}
            <div className="bg-white rounded-full p-2 pl-6 flex flex-col md:flex-row items-center shadow-2xl max-w-xl w-full">
                <div className="flex-grow w-full md:w-auto">
                    <input 
                        type="text" 
                        placeholder="Search location..." 
                        className="w-full p-2 text-gray-700 bg-transparent focus:outline-none text-base placeholder-gray-400"
                    />
                </div>
                <button className="bg-[#4aa5f0] hover:bg-[#3b8cc4] text-white px-8 py-3 rounded-full font-bold text-sm transition-all shadow-md whitespace-nowrap w-full md:w-auto mt-2 md:mt-0">
                    Book Your Tour
                </button>
            </div>
            
            {/* Dots Indicator */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
                <div className="w-2 h-2 rounded-full bg-white/50"></div>
                <div className="w-2 h-2 rounded-full bg-white"></div>
                <div className="w-2 h-2 rounded-full bg-white/50"></div>
                <div className="w-2 h-2 rounded-full bg-white/50"></div>
            </div>
         </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
         
         {/* 2. DISCIPLINES TABS */}
         <div className="text-center mb-12">
            <h2 className="text-4xl font-black text-gray-900 mb-8">Disciplines to practise</h2>
            <div className="flex flex-wrap justify-center gap-4">
                {sportsTabs.map(tab => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`px-8 py-2.5 rounded-full border text-sm font-bold transition-all duration-300 ${
                            activeTab === tab 
                            ? 'bg-[#4aa5f0] text-white border-[#4aa5f0] shadow-lg shadow-blue-200' 
                            : 'bg-white text-gray-600 border-gray-300 hover:border-[#4aa5f0] hover:text-[#4aa5f0]'
                        }`}
                    >
                        {tab}
                    </button>
                ))}
            </div>
         </div>

         {/* 3. INSPIRATION GRID (2x2) */}
         <div className="grid grid-cols-2 gap-4 mb-20">
            <div className="space-y-4">
                <img src={gridImages[0]} className="w-full h-64 object-cover rounded-2xl shadow-md hover:scale-[1.02] transition-transform duration-500" alt="Sport 1" />
                <img src={gridImages[1]} className="w-full h-48 object-cover rounded-2xl shadow-md hover:scale-[1.02] transition-transform duration-500" alt="Sport 2" />
            </div>
            <div className="space-y-4 pt-8">
                <img src={gridImages[2]} className="w-full h-48 object-cover rounded-2xl shadow-md hover:scale-[1.02] transition-transform duration-500" alt="Sport 3" />
                <img src={gridImages[3]} className="w-full h-64 object-cover rounded-2xl shadow-md hover:scale-[1.02] transition-transform duration-500" alt="Sport 4" />
            </div>
         </div>
         
         <div className="flex justify-center gap-2 mb-16">
                <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
                <div className="w-1.5 h-1.5 rounded-full bg-gray-800"></div>
                <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
                <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
         </div>


         {/* 4. TOP SCHOOLS LIST (Horizontal Cards) */}
         <div className="mb-20">
            <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Top 3 Schools to Learn {activeTab}</h2>
                <p className="text-xs text-gray-400 max-w-md mx-auto">
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.
                </p>
            </div>

            <div className="space-y-8">
                {displayListings.map(l => (
                    <div key={l.id} className="flex flex-col md:flex-row gap-6 group cursor-pointer hover:bg-gray-50 p-4 rounded-2xl transition-colors">
                        {/* Image Left */}
                        <div className="w-full md:w-64 h-48 flex-shrink-0 rounded-2xl overflow-hidden shadow-md relative">
                            <img src={l.images[0]} alt={l.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                            <div className="absolute top-2 left-2 bg-white/90 backdrop-blur px-2 py-0.5 rounded text-xs font-bold text-gray-800">
                                {l.providerName}
                            </div>
                        </div>

                        {/* Content Right */}
                        <div className="flex-grow flex flex-col justify-center">
                            <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-[#4aa5f0] transition-colors">
                                {l.providerName || l.title}
                            </h3>
                            <div className="flex items-center mb-3">
                                <span className="text-lg font-bold text-gray-900 mr-2">{l.rating}</span>
                                <div className="flex text-yellow-400 text-sm mr-2">
                                    {[...Array(5)].map((_,i) => <Star key={i} className={`w-4 h-4 ${i < Math.floor(l.rating) ? 'fill-current' : 'text-gray-300'}`} />)}
                                </div>
                                <span className="text-sm text-gray-500">({l.reviewCount} reviews)</span>
                            </div>
                            
                            <p className="text-sm text-gray-600 leading-relaxed mb-4 line-clamp-3">
                                {l.description.length > 150 ? l.description.substring(0, 150) + "..." : l.description} 
                                Experience the best {l.sport} sessions with certified instructors in {l.location.city}.
                                Safety and fun are guaranteed for all levels.
                            </p>

                            <Link 
                                to={`/${l.type.toLowerCase()}/${l.id}`} 
                                className="inline-flex items-center text-sm font-bold text-gray-900 hover:text-[#4aa5f0] transition-colors"
                            >
                                View Details <ArrowRight className="w-4 h-4 ml-1" />
                            </Link>
                        </div>
                    </div>
                ))}

                {displayListings.length === 0 && (
                    <div className="text-center py-10 text-gray-500">
                        No specific schools found for {activeTab} in this region.
                    </div>
                )}
            </div>
         </div>

         {/* 5. ALL ACTIVITIES (Legacy Request kept for density) */}
         <div className="pt-12 border-t border-gray-100">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">All Activities in {formattedName}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {listings.map(l => (
                    <ListingCard key={l.id} listing={l} />
                ))}
            </div>
         </div>

      </div>
    </div>
  );
};

export default DestinationLanding;
