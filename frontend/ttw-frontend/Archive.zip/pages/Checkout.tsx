
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { getListingById, createBooking } from '../services/dataService';
import { Listing, BookingStatus } from '../types';
import { Lock, CreditCard, CheckCircle } from 'lucide-react';

const Checkout: React.FC = () => {
  const { search } = useLocation();
  const navigate = useNavigate();
  const params = new URLSearchParams(search);
  const listingId = params.get('listingId');
  const date = params.get('date');
  const guests = Number(params.get('guests')) || 1;
  const size = params.get('size');

  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [completed, setCompleted] = useState(false);

  // Form State
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');

  useEffect(() => {
    const fetch = async () => {
      if(listingId) {
        const data = await getListingById(listingId);
        setListing(data || null);
      }
      setLoading(false);
    };
    fetch();
  }, [listingId]);

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if(!listing) return;
    
    setProcessing(true);
    
    // Simulate API call to Stripe + Backend
    await createBooking({
        listingId: listing.id,
        listingTitle: listing.title,
        listingImage: listing.images[0],
        userId: 'current-user-id', // Mocked
        providerId: listing.providerId,
        date: date || new Date().toISOString(),
        totalPrice: listing.price * guests * 1.1, // + Fee
        currency: listing.currency,
        guests: guests,
        selectedSize: size || undefined
    });

    setProcessing(false);
    setCompleted(true);
    
    // Redirect to dashboard after 3s
    setTimeout(() => {
        navigate('/dashboard');
    }, 3000);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  
  if (completed) {
      return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
              <div className="bg-white p-8 rounded-2xl shadow-xl text-center max-w-md w-full">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle className="w-10 h-10 text-green-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h2>
                  <p className="text-gray-600 mb-6">Your adventure is secured. Check your email for the receipt and instructor details.</p>
                  <button onClick={() => navigate('/dashboard')} className="w-full bg-gray-900 text-white py-3 rounded-lg font-bold">
                      Go to My Trips
                  </button>
              </div>
          </div>
      )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12">
        
        {/* Order Summary */}
        <div className="lg:order-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Order Summary</h3>
                {listing && (
                    <div className="flex gap-4 mb-6 pb-6 border-b border-gray-100">
                        <img src={listing.images[0]} alt="Listing" className="w-20 h-20 rounded-lg object-cover" />
                        <div>
                            <p className="font-bold text-gray-900 line-clamp-2">{listing.title}</p>
                            <p className="text-sm text-gray-500 mt-1">{listing.type}</p>
                            <div className="flex items-center text-xs text-brand-600 font-bold mt-1">
                                4.9 (120 reviews)
                            </div>
                        </div>
                    </div>
                )}
                
                <div className="space-y-3 text-sm text-gray-600">
                    <div className="flex justify-between">
                        <span>Date</span>
                        <span className="font-medium text-gray-900">{date || 'Select date'}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Guests</span>
                        <span className="font-medium text-gray-900">{guests}</span>
                    </div>
                    {size && (
                        <div className="flex justify-between">
                            <span>Size</span>
                            <span className="font-medium text-gray-900">{size}</span>
                        </div>
                    )}
                    <div className="flex justify-between">
                        <span>Price per person</span>
                        <span>{listing?.currency} {listing?.price}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Service Fee (10%)</span>
                        <span>{listing?.currency} {listing ? Math.round(listing.price * guests * 0.1) : 0}</span>
                    </div>
                    <div className="pt-4 border-t border-gray-200 flex justify-between items-center">
                        <span className="font-bold text-gray-900 text-lg">Total</span>
                        <span className="font-bold text-gray-900 text-lg">
                            {listing?.currency} {listing ? Math.round(listing.price * guests * 1.1) : 0}
                        </span>
                    </div>
                </div>
            </div>
        </div>

        {/* Checkout Form */}
        <div className="lg:order-1">
            <div className="flex items-center mb-8">
                 <Lock className="w-5 h-5 text-green-600 mr-2" />
                 <h1 className="text-2xl font-bold text-gray-900">Secure Checkout</h1>
            </div>

            <form onSubmit={handlePayment} className="space-y-8">
                
                <div className="bg-white p-6 rounded-xl border border-gray-200">
                    <h3 className="font-bold text-gray-900 mb-4">Personal Information</h3>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">First Name</label>
                            <input type="text" className="w-full border-gray-300 rounded-lg text-sm" placeholder="John" required />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Last Name</label>
                            <input type="text" className="w-full border-gray-300 rounded-lg text-sm" placeholder="Doe" required />
                        </div>
                        <div className="col-span-2">
                            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Email</label>
                            <input type="email" className="w-full border-gray-300 rounded-lg text-sm" placeholder="john@example.com" required />
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl border border-gray-200">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center">
                        <CreditCard className="w-5 h-5 mr-2" /> Payment Method
                    </h3>
                    <div className="space-y-4">
                        <div>
                             <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Card Number</label>
                             <input 
                                value={cardNumber}
                                onChange={e => setCardNumber(e.target.value)}
                                type="text" 
                                className="w-full border-gray-300 rounded-lg text-sm" 
                                placeholder="0000 0000 0000 0000" 
                                required 
                             />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                             <div>
                                <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Expiry</label>
                                <input 
                                    value={expiry}
                                    onChange={e => setExpiry(e.target.value)}
                                    type="text" 
                                    className="w-full border-gray-300 rounded-lg text-sm" 
                                    placeholder="MM/YY" 
                                    required 
                                />
                             </div>
                             <div>
                                <label className="block text-xs font-bold text-gray-700 uppercase mb-1">CVC</label>
                                <input 
                                    value={cvc}
                                    onChange={e => setCvc(e.target.value)}
                                    type="text" 
                                    className="w-full border-gray-300 rounded-lg text-sm" 
                                    placeholder="123" 
                                    required 
                                />
                             </div>
                        </div>
                    </div>
                    
                    <div className="mt-4 flex items-center text-xs text-gray-500">
                        <Lock className="w-3 h-3 mr-1" /> Payments are processed securely by Stripe.
                    </div>
                </div>

                <button 
                    type="submit" 
                    disabled={processing}
                    className="w-full bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg transition-all disabled:opacity-70 disabled:cursor-not-allowed flex justify-center items-center"
                >
                    {processing ? (
                        <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                        `Confirm & Pay ${listing?.currency} ${listing ? Math.round(listing.price * guests * 1.1) : 0}`
                    )}
                </button>

            </form>
        </div>

      </div>
    </div>
  );
};

export default Checkout;
