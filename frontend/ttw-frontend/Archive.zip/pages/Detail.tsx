
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Listing, ListingType } from '../types';
import { getListingById } from '../services/dataService';
import { generateSafetyBriefing, generateTripItinerary, askAIAboutListing } from '../services/geminiService';
import { Star, MapPin, Shield, Info, Calendar, Sparkles, Send } from 'lucide-react';

const Detail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Booking State
  const [selectedDate, setSelectedDate] = useState('');
  const [guests, setGuests] = useState(1);
  const [selectedSize, setSelectedSize] = useState('');

  // AI States
  const [safetyTips, setSafetyTips] = useState<string | null>(null);
  const [itinerary, setItinerary] = useState<{day: number, title: string, desc: string}[] | null>(null);
  const [aiChatInput, setAiChatInput] = useState('');
  const [aiChatResponse, setAiChatResponse] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      if (!id) return;
      const data = await getListingById(id);
      setListing(data || null);
      setLoading(false);
    };
    fetch();
  }, [id]);

  const handleReserve = () => {
      if(!listing) return;
      const params = new URLSearchParams({
          listingId: listing.id,
          date: selectedDate,
          guests: guests.toString(),
      });
      if(selectedSize) params.append('size', selectedSize);
      
      navigate(`/checkout?${params.toString()}`);
  };

  // AI Actions
  const handleGenerateSafety = async () => {
    if (!listing) return;
    setIsAiThinking(true);
    const tips = await generateSafetyBriefing(listing.sport, listing.difficulty || 'General', listing.location.country);
    setSafetyTips(tips);
    setIsAiThinking(false);
  };

  const handleGenerateItinerary = async () => {
    if (!listing) return;
    setIsAiThinking(true);
    const jsonStr = await generateTripItinerary(listing.title, 5, listing.location.country);
    try {
      const parsed = JSON.parse(jsonStr);
      setItinerary(parsed);
    } catch (e) {
        console.error(e);
    }
    setIsAiThinking(false);
  };

  const handleAskAI = async () => {
    if (!listing || !aiChatInput) return;
    setIsAiThinking(true);
    const response = await askAIAboutListing(listing, aiChatInput);
    setAiChatResponse(response);
    setIsAiThinking(false);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!listing) return <div className="min-h-screen flex items-center justify-center">Listing not found</div>;

  return (
    <div className="bg-white min-h-screen pb-20">
      {/* Hero Gallery */}
      <div className="h-[50vh] md:h-[60vh] w-full relative bg-gray-900">
        <img src={listing.images[0]} alt={listing.title} className="w-full h-full object-cover opacity-90" />
        <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 to-transparent p-8">
            <div className="max-w-7xl mx-auto">
                <span className="bg-brand-600 text-white px-3 py-1 rounded text-xs font-bold uppercase tracking-wider mb-4 inline-block">
                    {listing.type} • {listing.sport}
                </span>
                <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">{listing.title}</h1>
                <div className="flex items-center text-white/90 space-x-4">
                    <span className="flex items-center"><MapPin className="w-4 h-4 mr-1"/> {listing.location.city}, {listing.location.country}</span>
                    <span className="flex items-center"><Star className="w-4 h-4 mr-1 text-yellow-400 fill-yellow-400"/> {listing.rating} ({listing.reviewCount} reviews)</span>
                </div>
            </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-10">
            
            {/* Provider Info */}
            <div className="flex items-center justify-between border-b border-gray-100 pb-6">
                <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full overflow-hidden">
                        <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${listing.providerName}`} alt="Provider" />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500">Hosted by</p>
                        <p className="font-bold text-gray-900 flex items-center">
                            {listing.providerName}
                            {listing.isVerified && <Shield className="w-4 h-4 text-brand-500 ml-1" />}
                        </p>
                    </div>
                </div>
                {listing.difficulty && (
                    <div className="text-right">
                        <p className="text-sm text-gray-500">Difficulty</p>
                        <span className="inline-block bg-gray-100 text-gray-800 font-bold px-3 py-1 rounded-lg mt-1">
                            {listing.difficulty}
                        </span>
                    </div>
                )}
            </div>

            {/* Description */}
            <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">About this experience</h2>
                <p className="text-gray-600 leading-relaxed whitespace-pre-line">{listing.description}</p>
            </div>

            {/* AI Section: Safety */}
            <div className="bg-orange-50 border border-orange-100 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-orange-900 flex items-center">
                        <Info className="w-5 h-5 mr-2" /> Safety First
                    </h3>
                    {!safetyTips && (
                        <button 
                            onClick={handleGenerateSafety}
                            disabled={isAiThinking}
                            className="text-xs bg-white border border-orange-200 text-orange-700 px-3 py-1.5 rounded-full font-medium hover:bg-orange-100 flex items-center"
                        >
                           <Sparkles className="w-3 h-3 mr-1" /> Generate AI Safety Brief
                        </button>
                    )}
                </div>
                {safetyTips && (
                    <div className="prose prose-sm prose-orange text-orange-800">
                        <ul className="list-disc pl-4 space-y-1">
                            {safetyTips.split('\n').filter(l => l.includes('-') || l.includes('*')).map((line, i) => (
                                <li key={i}>{line.replace(/^[-*]\s*/, '')}</li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>

            {/* Trip Itinerary (Only for Trips) */}
            {listing.type === ListingType.TRIP && (
                 <div className="border border-gray-200 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-bold text-gray-900">Itinerary</h3>
                        {!itinerary && (
                            <button 
                                onClick={handleGenerateItinerary}
                                disabled={isAiThinking}
                                className="text-xs bg-brand-50 text-brand-700 px-3 py-1.5 rounded-full font-medium hover:bg-brand-100 flex items-center"
                            >
                               <Sparkles className="w-3 h-3 mr-1" /> Reveal Day-by-Day
                            </button>
                        )}
                    </div>
                    {itinerary ? (
                        <div className="space-y-6 relative border-l border-gray-200 ml-3 pl-8">
                            {itinerary.map((item, idx) => (
                                <div key={idx} className="relative">
                                    <span className="absolute -left-[41px] top-0 flex items-center justify-center w-6 h-6 bg-brand-100 rounded-full ring-4 ring-white">
                                        <span className="text-xs font-bold text-brand-600">{item.day}</span>
                                    </span>
                                    <h4 className="text-md font-bold text-gray-900 mb-1">{item.title}</h4>
                                    <p className="text-sm text-gray-600">{item.desc}</p>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-8 text-gray-400 italic text-sm">
                            Click button to generate a smart itinerary based on location and duration.
                        </div>
                    )}
                 </div>
            )}

            {/* AI Q&A */}
            <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="font-bold text-gray-900 mb-4 flex items-center"><Sparkles className="w-4 h-4 mr-2 text-purple-500"/> Ask AI about this trip</h3>
                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={aiChatInput}
                        onChange={(e) => setAiChatInput(e.target.value)}
                        placeholder="e.g., Is this suitable for kids? What's the water temp?"
                        className="flex-grow border-gray-300 rounded-lg focus:ring-brand-500 focus:border-brand-500"
                    />
                    <button 
                        onClick={handleAskAI}
                        disabled={isAiThinking}
                        className="bg-gray-900 text-white px-4 rounded-lg hover:bg-gray-800 disabled:opacity-50"
                    >
                        <Send className="w-4 h-4" />
                    </button>
                </div>
                {aiChatResponse && (
                    <div className="mt-4 bg-white p-4 rounded-lg border border-gray-200 text-sm text-gray-700">
                        {aiChatResponse}
                    </div>
                )}
            </div>

        </div>

        {/* Booking Sidebar */}
        <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 sticky top-24">
                <div className="flex items-end justify-between mb-6">
                    <div>
                        <span className="text-2xl font-bold text-gray-900">{listing.currency} {listing.price}</span>
                        <span className="text-gray-500 text-sm"> / person</span>
                    </div>
                    <div className="flex items-center text-xs font-bold text-gray-600">
                        <Star className="w-3 h-3 text-brand-500 fill-brand-500 mr-1" />
                        {listing.rating}
                    </div>
                </div>

                <div className="space-y-4 mb-6">
                    <div className="grid grid-cols-2 gap-2">
                        <div className="border border-gray-300 rounded-lg p-3">
                            <label className="block text-xs text-gray-500 uppercase font-bold mb-1">Check-in</label>
                            <input 
                                type="date" 
                                className="w-full text-sm outline-none" 
                                value={selectedDate}
                                onChange={(e) => setSelectedDate(e.target.value)}
                            />
                        </div>
                        <div className="border border-gray-300 rounded-lg p-3">
                             <label className="block text-xs text-gray-500 uppercase font-bold mb-1">Guests</label>
                             <select 
                                value={guests}
                                onChange={(e) => setGuests(Number(e.target.value))}
                                className="w-full text-sm outline-none bg-transparent"
                             >
                                {[1,2,3,4,5,6].map(n => <option key={n} value={n}>{n} Guest{n>1?'s':''}</option>)}
                             </select>
                        </div>
                    </div>
                    
                    {listing.type === ListingType.RENT && listing.availableSizes && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Select Size</label>
                            <div className="flex gap-2">
                                {listing.availableSizes.map(size => (
                                    <button 
                                        key={size} 
                                        onClick={() => setSelectedSize(size)}
                                        className={`px-3 py-1 border rounded text-sm transition-colors ${selectedSize === size ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-gray-300 hover:border-brand-500'}`}
                                    >
                                        {size}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                <button 
                    onClick={handleReserve}
                    className="w-full bg-brand-600 text-white py-3 rounded-lg font-bold text-lg hover:bg-brand-700 transition-colors shadow-md shadow-brand-200"
                >
                    Reserve Now
                </button>
                <p className="text-center text-xs text-gray-500 mt-3">You won't be charged yet</p>
                
                <div className="mt-6 pt-6 border-t border-gray-100 space-y-3 text-sm text-gray-600">
                     <div className="flex justify-between">
                         <span>Service fee</span>
                         <span>{listing.currency} {Math.round(listing.price * guests * 0.1)}</span>
                     </div>
                     <div className="flex justify-between font-bold text-gray-900 text-base pt-2">
                         <span>Total</span>
                         <span>{listing.currency} {Math.round(listing.price * guests * 1.1)}</span>
                     </div>
                </div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default Detail;
