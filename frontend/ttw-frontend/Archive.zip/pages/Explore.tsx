import React, { useState, useEffect } from 'react';
import { Filter, Search, Map as MapIcon, List } from 'lucide-react';
import { Listing, ListingType, SportCategory } from '../types';
import { getListings } from '../services/dataService';
import ListingCard from '../components/ListingCard';
import { MOCK_CONTINENTS, SPORTS_BY_CATEGORY } from '../constants';

const Explore: React.FC = () => {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'GRID' | 'MAP'>('GRID');

  // Filters State
  const [selectedType, setSelectedType] = useState<ListingType | 'ALL'>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<SportCategory | 'ALL'>('ALL');
  const [selectedSport, setSelectedSport] = useState<string>('');
  const [selectedContinent, setSelectedContinent] = useState<string>('');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 5000]);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      const data = await getListings({
        type: selectedType,
        sport: selectedSport,
        // In a real app, more filters would be passed to the backend
      });
      setListings(data);
      setLoading(false);
    };
    fetch();
  }, [selectedType, selectedSport, selectedContinent]); // Re-fetch on filter change

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Sub-header Filters */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            {/* Type Switcher */}
            <div className="flex space-x-2 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
              {['ALL', ...Object.values(ListingType)].map(type => (
                <button
                  key={type}
                  onClick={() => setSelectedType(type as any)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                    selectedType === type 
                    ? 'bg-gray-900 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {type === 'ALL' ? 'All Experiences' : type === 'RENT' ? 'Rentals' : type === 'TRIP' ? 'Trips' : 'Activities'}
                </button>
              ))}
            </div>

            {/* Search Bar */}
            <div className="relative flex-grow md:max-w-md">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-brand-500 focus:border-brand-500 sm:text-sm"
                placeholder="Search by destination, sport or keyword..."
              />
            </div>

            {/* View Toggle */}
            <div className="flex items-center border border-gray-300 rounded-lg bg-white p-1">
              <button 
                onClick={() => setViewMode('GRID')}
                className={`p-2 rounded ${viewMode === 'GRID' ? 'bg-gray-100 text-gray-900' : 'text-gray-500'}`}
              >
                <List className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setViewMode('MAP')}
                className={`p-2 rounded ${viewMode === 'MAP' ? 'bg-gray-100 text-gray-900' : 'text-gray-500'}`}
              >
                <MapIcon className="w-5 h-5" />
              </button>
            </div>

          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow w-full flex flex-col lg:flex-row gap-8">
        
        {/* Sidebar Filters */}
        <aside className="w-full lg:w-64 flex-shrink-0 space-y-8">
          
          {/* Continent Filter */}
          <div>
             <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Geography</h3>
             <select 
                className="w-full border-gray-300 rounded-md shadow-sm focus:border-brand-500 focus:ring-brand-500 text-sm"
                value={selectedContinent}
                onChange={(e) => setSelectedContinent(e.target.value)}
             >
               <option value="">Anywhere</option>
               {MOCK_CONTINENTS.map(c => <option key={c} value={c}>{c}</option>)}
             </select>
          </div>

          {/* Sports Category Filter */}
          <div>
            <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Discipline</h3>
            <div className="space-y-2">
              {Object.values(SportCategory).map(cat => (
                <div key={cat} className="flex items-center">
                  <input
                    id={`cat-${cat}`}
                    name="category"
                    type="radio"
                    checked={selectedCategory === cat}
                    onChange={() => setSelectedCategory(cat)}
                    className="focus:ring-brand-500 h-4 w-4 text-brand-600 border-gray-300"
                  />
                  <label htmlFor={`cat-${cat}`} className="ml-3 block text-sm font-medium text-gray-700">
                    {cat}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Dynamic Specific Sport Filter */}
          {selectedCategory !== 'ALL' && (
            <div className="animate-fade-in">
               <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Sport</h3>
               <select 
                 className="w-full border-gray-300 rounded-md shadow-sm focus:border-brand-500 focus:ring-brand-500 text-sm"
                 value={selectedSport}
                 onChange={(e) => setSelectedSport(e.target.value)}
               >
                 <option value="">All {selectedCategory} Sports</option>
                 {SPORTS_BY_CATEGORY[selectedCategory].map(s => (
                   <option key={s} value={s}>{s}</option>
                 ))}
               </select>
            </div>
          )}

          {/* Price Range Slider Mockup */}
          <div>
            <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Price Range</h3>
            <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
            </div>
            <input 
                type="range" 
                min="0" 
                max="5000" 
                step="100"
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
          </div>

        </aside>

        {/* Results Grid */}
        <main className="flex-grow">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
              </div>
            ) : (
              <>
                {viewMode === 'GRID' ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {listings.map(l => (
                        <ListingCard key={l.id} listing={l} />
                      ))}
                      {listings.length === 0 && (
                        <div className="col-span-full text-center py-20 bg-white rounded-xl border border-dashed border-gray-300">
                          <p className="text-gray-500 text-lg">No adventures found matching your criteria.</p>
                          <button onClick={() => {setSelectedType('ALL'); setSelectedContinent('')}} className="mt-4 text-brand-600 hover:underline">Clear Filters</button>
                        </div>
                      )}
                    </div>
                ) : (
                    <div className="bg-gray-200 rounded-xl h-[600px] flex items-center justify-center relative overflow-hidden">
                        <div className="text-center p-8 bg-white/80 backdrop-blur-md rounded-lg shadow-lg max-w-md">
                            <MapIcon className="w-12 h-12 text-brand-600 mx-auto mb-4" />
                            <h3 className="text-xl font-bold text-gray-900 mb-2">Interactive Map View</h3>
                            <p className="text-gray-600 mb-4">
                                This would render a Google Maps or OpenStreetMap interface clustering the {listings.length} results geographically.
                            </p>
                            <p className="text-xs text-gray-500">Requires API Key integration for production.</p>
                        </div>
                    </div>
                )}
              </>
            )}
        </main>

      </div>
    </div>
  );
};

export default Explore;