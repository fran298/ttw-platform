
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAvailableCountries } from '../services/dataService';
import { MapPin, ArrowRight, Compass } from 'lucide-react';

interface CountryData {
    name: string;
    image: string;
    count: number;
    continent: string;
}

const DestinationsIndex: React.FC = () => {
    const [countries, setCountries] = useState<CountryData[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetch = async () => {
            const data = await getAvailableCountries();
            setCountries(data);
            setLoading(false);
        };
        fetch();
    }, []);

    return (
        <div className="min-h-screen bg-white">
            {/* Hero Section */}
            <div className="relative h-[40vh] bg-gray-900 overflow-hidden">
                <img 
                    src="https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1600&q=80" 
                    alt="World Map" 
                    className="w-full h-full object-cover opacity-50"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-transparent flex flex-col items-center justify-center text-center px-4">
                    <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-md px-4 py-1.5 rounded-full mb-6 border border-white/20">
                        <Compass className="w-4 h-4 text-brand-400" />
                        <span className="text-brand-100 font-bold tracking-widest uppercase text-xs">The World is Yours</span>
                    </div>
                    <h1 className="text-5xl md:text-6xl font-black text-white mb-4 tracking-tight">Explore Destinations</h1>
                    <p className="text-xl text-gray-200 max-w-2xl font-light">
                        Discover the best spots for extreme sports across the globe. Only showing destinations with active adventures.
                    </p>
                </div>
            </div>

            {/* Content Section */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
                
                {loading ? (
                    <div className="flex justify-center items-center h-64">
                         <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        {countries.map((country) => (
                            <Link 
                                key={country.name} 
                                to={`/destination/${country.name.toLowerCase()}`}
                                className="group relative h-96 rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2"
                            >
                                {/* Background Image */}
                                <img 
                                    src={country.image} 
                                    alt={country.name} 
                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                                />
                                {/* Overlay Gradient */}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
                                
                                {/* Continent Badge */}
                                <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-white uppercase tracking-wider border border-white/30 shadow-sm">
                                    {country.continent}
                                </div>

                                {/* Content Bottom */}
                                <div className="absolute bottom-0 left-0 w-full p-8 text-white">
                                    <h3 className="text-4xl font-black mb-2 tracking-tight group-hover:text-brand-400 transition-colors">{country.name}</h3>
                                    
                                    <div className="flex items-center justify-between border-t border-white/20 pt-4 mt-2">
                                        <div className="flex items-center text-sm font-medium text-gray-300">
                                            <MapPin className="w-4 h-4 mr-2 text-brand-500" />
                                            {country.count} {country.count === 1 ? 'Adventure' : 'Adventures'} Available
                                        </div>
                                        
                                        <div className="flex items-center text-brand-400 text-sm font-bold opacity-0 group-hover:opacity-100 transform translate-x-4 group-hover:translate-x-0 transition-all duration-300">
                                            Explore <ArrowRight className="w-4 h-4 ml-1" />
                                        </div>
                                    </div>
                                </div>
                            </Link>
                        ))}
                    </div>
                )}

                {!loading && countries.length === 0 && (
                    <div className="text-center py-20 bg-gray-50 rounded-3xl border border-dashed border-gray-300">
                        <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-bold text-gray-900 mb-2">No Destinations Found</h3>
                        <p className="text-gray-500 text-lg">It looks like we don't have any active listings right now.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default DestinationsIndex;
