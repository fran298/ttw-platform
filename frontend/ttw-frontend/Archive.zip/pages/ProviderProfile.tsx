
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProviderProfile } from '../services/dataService';
import { ProviderProfile } from '../types';
import { ShieldCheck, MapPin, Link as LinkIcon, Instagram, Youtube, Globe, Eye, MessageCircle, Heart, Star } from 'lucide-react';

const ProviderProfilePage: React.FC = () => {
  const { providerId } = useParams<{ providerId: string }>();
  const [profile, setProfile] = useState<ProviderProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'DISCIPLINES' | 'CERTIFICATIONS' | 'JOBS'>('DISCIPLINES');

  useEffect(() => {
    const fetch = async () => {
      // Use mock ID "p1" regardless of param for demo purposes to show data
      const data = await getProviderProfile('p1');
      setProfile(data);
      setLoading(false);
    };
    fetch();
  }, [providerId]);

  if (loading) return <div className="min-h-screen flex justify-center items-center">Loading...</div>;
  if (!profile) return <div className="min-h-screen flex justify-center items-center">Provider not found</div>;

  return (
    <div className="bg-white min-h-screen">
      {/* Banner / Cover - Optional, but adds flair. Mockup has a green header. */}
      <div className="h-48 md:h-64 bg-gray-900 relative overflow-hidden">
        <img 
            src="https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?auto=format&fit=crop&w=1600&q=80" 
            alt="Cover" 
            className="w-full h-full object-cover opacity-60" 
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
            
            {/* LEFT SIDEBAR (Sticky) */}
            <aside className="lg:col-span-1 -mt-20 relative z-10">
                <div className="bg-white rounded-none md:rounded-lg shadow-none md:shadow-none"> {/* Simplified as per mockup style which looks clean */}
                    
                    {/* Logo & Header */}
                    <div className="flex flex-col items-center text-center md:items-start md:text-left mb-6">
                        <div className="w-32 h-32 rounded-full border-4 border-white shadow-md overflow-hidden bg-white mb-4">
                            <img src={profile.logo} alt={profile.name} className="w-full h-full object-cover" />
                        </div>
                        <h1 className="text-2xl font-black text-gray-900 flex items-center gap-2">
                            {profile.name}
                            {profile.isVerified && <ShieldCheck className="w-6 h-6 text-blue-500 fill-blue-50" />}
                        </h1>

                        {/* Verification Badge */}
                        {profile.isVerified && (
                            <div className="mt-2 group relative inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100 cursor-help transition-colors hover:bg-blue-100 hover:border-blue-200">
                                <ShieldCheck className="w-3 h-3 mr-1.5" />
                                Verified Partner
                                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-56 bg-gray-900 text-white text-xs font-normal p-3 rounded-lg shadow-xl opacity-0 group-hover:opacity-100 transition-opacity z-50 text-center pointer-events-none">
                                    <p className="font-bold mb-1 text-blue-200">Advanced Verification</p>
                                    <p className="leading-snug">Documents uploaded & Stripe Connect onboarding completed.</p>
                                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
                                </div>
                            </div>
                        )}
                        
                        {/* Sports Tags */}
                        <div className="flex flex-wrap gap-2 mt-4 justify-center md:justify-start">
                            {profile.sports.map(sport => (
                                <span key={sport} className="text-xs font-bold text-gray-600 uppercase tracking-wide">
                                    {sport} {sport !== profile.sports[profile.sports.length-1] && '-'}
                                </span>
                            ))}
                        </div>

                        {/* Location */}
                        <div className="flex items-center text-gray-500 text-sm mt-2">
                            <MapPin className="w-4 h-4 mr-1" />
                            {profile.location}
                        </div>

                        {/* Web Link */}
                        {profile.socials.web && (
                             <a 
                                href={profile.socials.web.startsWith('http') ? profile.socials.web : `https://${profile.socials.web}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center text-gray-400 text-xs mt-1 hover:text-brand-600 transition-colors"
                             >
                                <Globe className="w-3 h-3 mr-1" />
                                {profile.socials.web}
                            </a>
                        )}
                    </div>

                    {/* CTAs */}
                    <div className="space-y-3 mb-8">
                        <button className="w-full bg-[#5865F2] hover:bg-[#4752c4] text-white font-bold py-2.5 rounded-lg transition-colors shadow-sm">
                            Follow
                        </button>
                        <button className="w-full bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 font-bold py-2.5 rounded-lg transition-colors shadow-sm">
                            Messenge
                        </button>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 mb-8 border-t border-b border-gray-100 py-4">
                        <div className="flex justify-between">
                            <span>Views of Wild Stories</span>
                            <span className="font-bold text-gray-900">{profile.stats.views}</span>
                        </div>
                        <div className="flex justify-between">
                            <span>Reviews</span>
                            <span className="font-bold text-gray-900">{profile.stats.reviews}</span>
                        </div>
                         <div className="flex justify-between">
                            <span>Trips</span>
                            <span className="font-bold text-gray-900">{profile.stats.trips}</span>
                        </div>
                    </div>

                    {/* Links */}
                    <div className="space-y-4 mb-8">
                        <h3 className="font-bold text-gray-900 text-sm">Links</h3>
                        {profile.socials.web && (
                            <a 
                                href={profile.socials.web.startsWith('http') ? profile.socials.web : `https://${profile.socials.web}`}
                                target="_blank"
                                rel="noopener noreferrer" 
                                className="flex items-center justify-between p-3 border border-gray-200 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer group"
                            >
                                <span className="font-bold text-sm text-gray-700 group-hover:text-brand-600">Web</span>
                                <LinkIcon className="w-4 h-4 text-gray-400 group-hover:text-brand-600" />
                            </a>
                        )}
                        {profile.socials.youtube && (
                            <a 
                                href={profile.socials.youtube.startsWith('http') ? profile.socials.youtube : `https://${profile.socials.youtube}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-between p-3 border border-gray-200 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer group"
                            >
                                <span className="font-bold text-sm text-gray-700 group-hover:text-red-600">You Tube</span>
                                <Youtube className="w-4 h-4 text-gray-400 group-hover:text-red-600" />
                            </a>
                        )}
                        {profile.socials.instagram && (
                             <a 
                                href={profile.socials.instagram.startsWith('http') ? profile.socials.instagram : `https://${profile.socials.instagram}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-between p-3 border border-gray-200 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer group"
                            >
                                <span className="font-bold text-sm text-gray-700 group-hover:text-pink-600">Instagram</span>
                                <Instagram className="w-4 h-4 text-gray-400 group-hover:text-pink-600" />
                            </a>
                        )}
                    </div>

                    {/* About */}
                    <div>
                        <h3 className="font-bold text-gray-900 text-sm uppercase mb-3">ABOUT ME:</h3>
                        <p className="text-xs text-gray-600 leading-relaxed text-justify">
                            {profile.bio}
                        </p>
                        <p className="text-xs text-gray-600 leading-relaxed text-justify mt-4">
                            Our motto is simple: Meet, Enjoy, and Share. So let's do it!
                        </p>
                    </div>

                </div>
            </aside>

            {/* RIGHT CONTENT */}
            <main className="lg:col-span-3 pt-8">
                
                {/* Tabs */}
                <div className="flex space-x-8 border-b border-gray-200 mb-8 overflow-x-auto">
                    {['Disciplines', 'Certifications', 'Job opportunities'].map((tab) => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab as any)}
                            className={`pb-4 text-sm font-bold tracking-wide uppercase whitespace-nowrap ${
                                activeTab === tab 
                                ? 'border-b-2 border-gray-900 text-gray-900' 
                                : 'text-gray-400 hover:text-gray-600'
                            }`}
                        >
                            {tab}
                        </button>
                    ))}
                </div>

                {/* Disciplines Grid (Gallery style) */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-16">
                     {/* KITESURF */}
                     <div className="relative aspect-video md:aspect-[4/3] group cursor-pointer overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Kitesurf" />
                        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                        <span className="absolute bottom-4 left-0 right-0 text-center text-white font-black text-2xl uppercase tracking-tighter drop-shadow-md">Kitesurf</span>
                     </div>
                     {/* WINGFOIL */}
                     <div className="relative aspect-video md:aspect-[4/3] group cursor-pointer overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1612459468698-0c309315589c?auto=format&fit=crop&w=600&q=80" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Wingfoil" />
                        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                        <span className="absolute bottom-4 left-0 right-0 text-center text-white font-black text-2xl uppercase tracking-tighter drop-shadow-md">Wingfoil</span>
                     </div>
                     {/* SURF */}
                     <div className="relative aspect-video md:aspect-[4/3] group cursor-pointer overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=600&q=80" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Surf" />
                        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                        <span className="absolute bottom-4 left-0 right-0 text-center text-white font-black text-2xl uppercase tracking-tighter drop-shadow-md">Surf</span>
                     </div>
                     {/* SUP */}
                     <div className="relative aspect-video md:aspect-[4/3] group cursor-pointer overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1543743590-d476479b47e0?auto=format&fit=crop&w=600&q=80" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="SUP" />
                         <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                        <span className="absolute bottom-4 left-0 right-0 text-center text-white font-black text-2xl uppercase tracking-tighter drop-shadow-md">Stand Up Paddle</span>
                     </div>
                     {/* WAKEFOIL */}
                     <div className="relative aspect-video md:aspect-[4/3] group cursor-pointer overflow-hidden">
                        <img src="https://images.unsplash.com/photo-1599388147250-9856f97d3416?auto=format&fit=crop&w=600&q=80" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Wakefoil" />
                         <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                        <span className="absolute bottom-4 left-0 right-0 text-center text-white font-black text-2xl uppercase tracking-tighter drop-shadow-md">Wakefoil</span>
                     </div>
                </div>

                {/* Reviews Section */}
                <div className="mb-16">
                    <h2 className="text-4xl font-black text-gray-900 text-center mb-10">Reviews</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {profile.reviews.map(review => (
                            <div key={review.id} className="bg-gray-100/50 p-6 rounded-2xl flex flex-col justify-between min-h-[200px]">
                                <div className="flex items-center gap-3 mb-4">
                                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                                        {review.userName.charAt(0)}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900 leading-tight">{review.userName}</h4>
                                        <p className="text-xs text-gray-500">{review.visitedLocation}</p>
                                    </div>
                                </div>
                                <div className="flex text-yellow-500 mb-3">
                                    {[...Array(review.rating)].map((_, i) => <Star key={i} className="w-4 h-4 fill-current" />)}
                                </div>
                                <p className="text-xs font-medium text-gray-600 italic text-center leading-relaxed">
                                    {review.comment}
                                </p>
                            </div>
                        ))}
                    </div>
                    {/* Dots indicator mock */}
                    <div className="flex justify-center gap-2 mt-6">
                        <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-800"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                    </div>
                </div>

                {/* Wild Stories Section */}
                <div>
                    <h2 className="text-4xl font-black text-gray-900 text-center mb-10">Wild Stories</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {profile.stories.map(story => (
                            <div key={story.id} className="group cursor-pointer">
                                <div className="aspect-[4/3] rounded-lg overflow-hidden mb-3 relative">
                                    <img src={story.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={story.title} />
                                </div>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h4 className="font-bold text-gray-900 text-sm leading-tight mb-1">{story.category}</h4>
                                        <p className="text-xs text-gray-500">{story.author}</p>
                                    </div>
                                    <div className="flex items-center gap-3 text-xs text-gray-400">
                                        <span className="flex items-center"><Heart className="w-3 h-3 mr-1" /> {story.likes}</span>
                                        <span className="flex items-center"><Eye className="w-3 h-3 mr-1" /> {story.views}</span>
                                    </div>
                                </div>
                                <h3 className="font-bold text-gray-800 mt-2 group-hover:text-blue-600 transition-colors text-sm">{story.title}</h3>
                            </div>
                        ))}
                    </div>
                    {/* Pagination Dots */}
                    <div className="flex justify-center gap-2 mt-12">
                        <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                        <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                    </div>
                </div>

            </main>

        </div>
      </div>
    </div>
  );
};

export default ProviderProfilePage;
