
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Users, DollarSign, CalendarCheck, AlertCircle, Plus, Package, List, Check, X } from 'lucide-react';
import { Booking, Listing, ListingType, SportCategory } from '../types';
import { getProviderBookings, createListing, getPendingListings, approveListing, getUserBookings } from '../services/dataService';

const data = [
  { name: 'Jan', bookings: 40, revenue: 2400 },
  { name: 'Feb', bookings: 30, revenue: 1398 },
  { name: 'Mar', bookings: 20, revenue: 9800 },
  { name: 'Apr', bookings: 27, revenue: 3908 },
  { name: 'May', bookings: 18, revenue: 4800 },
  { name: 'Jun', bookings: 23, revenue: 3800 },
];

interface Props {
  role: 'PROVIDER' | 'ADMIN' | 'USER'; // Added USER role for consistency
}

const Dashboard: React.FC<Props> = ({ role }) => {
  const [activeTab, setActiveTab] = useState('OVERVIEW');
  const [bookings, setBookings] = useState<Booking[]>([]);
  
  // Admin Specific
  const [pendingListings, setPendingListings] = useState<Listing[]>([]);

  // Provider Specific Form State
  const [newListingTitle, setNewListingTitle] = useState('');
  const [newListingType, setNewListingType] = useState<ListingType>(ListingType.ACTIVITY);
  const [newListingPrice, setNewListingPrice] = useState(0);
  const [newListingCategory, setNewListingCategory] = useState<SportCategory>(SportCategory.WATER);

  useEffect(() => {
      const fetch = async () => {
          if (role === 'PROVIDER') {
              const b = await getProviderBookings('p1');
              setBookings(b);
          } else if (role === 'ADMIN') {
              const l = await getPendingListings();
              setPendingListings(l);
          } else if (role === 'USER') {
              const ub = await getUserBookings('u1');
              setBookings(ub);
          }
      };
      fetch();
  }, [role, activeTab]);

  const handleCreateListing = async (e: React.FormEvent) => {
      e.preventDefault();
      await createListing({
          title: newListingTitle,
          type: newListingType,
          category: newListingCategory,
          price: newListingPrice,
          sport: 'Generic Sport', // Simplified for demo
          currency: 'USD',
          location: { continent: 'Europe', country: 'Spain', city: 'Tarifa', lat: 36, lng: -5 },
          providerName: 'Current User',
          providerId: 'p1',
          description: 'Auto-generated listing description.'
      });
      alert('Listing created! Sent for Admin approval.');
      setNewListingTitle('');
      setActiveTab('OVERVIEW');
  };

  const handleApprove = async (id: string) => {
      await approveListing(id);
      setPendingListings(pendingListings.filter(x => x.id !== id));
  };

  // --- USER DASHBOARD (My Trips) ---
  if (role === 'USER' || role === 'USER' as any) { // Quick fix for role prop passing from App
      return (
          <div className="min-h-screen bg-gray-50 p-8">
              <div className="max-w-5xl mx-auto">
                  <h1 className="text-3xl font-bold text-gray-900 mb-8">My Trips & Adventures</h1>
                  <div className="space-y-4">
                      {bookings.length === 0 ? (
                          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
                              <p className="text-gray-500">You haven't booked any adventures yet.</p>
                          </div>
                      ) : (
                          bookings.map(b => (
                              <div key={b.id} className="bg-white p-6 rounded-xl border border-gray-100 flex flex-col md:flex-row items-center gap-6 shadow-sm">
                                  <img src={b.listingImage} className="w-24 h-24 object-cover rounded-lg" alt="Thumb" />
                                  <div className="flex-grow">
                                      <div className="flex justify-between items-start">
                                          <div>
                                              <h3 className="text-lg font-bold text-gray-900">{b.listingTitle}</h3>
                                              <p className="text-sm text-gray-500">Booking ID: {b.id}</p>
                                          </div>
                                          <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-bold uppercase">{b.status}</span>
                                      </div>
                                      <div className="mt-4 flex gap-6 text-sm text-gray-600">
                                          <span className="flex items-center"><CalendarCheck className="w-4 h-4 mr-1"/> {b.date}</span>
                                          <span className="flex items-center"><Users className="w-4 h-4 mr-1"/> {b.guests} Guests</span>
                                          <span className="font-bold text-gray-900">{b.currency} {b.totalPrice}</span>
                                      </div>
                                  </div>
                              </div>
                          ))
                      )}
                  </div>
              </div>
          </div>
      );
  }

  // --- PROVIDER & ADMIN DASHBOARD ---
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white border-r border-gray-200 p-6">
        <div className="mb-8">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Menu</h2>
            <nav className="space-y-2">
                <button 
                    onClick={() => setActiveTab('OVERVIEW')}
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'OVERVIEW' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                    <BarChart className="w-5 h-5" />
                    <span>Overview</span>
                </button>
                {role === 'PROVIDER' && (
                    <>
                        <button 
                            onClick={() => setActiveTab('LISTINGS')}
                            className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'LISTINGS' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}
                        >
                            <List className="w-5 h-5" />
                            <span>My Listings</span>
                        </button>
                        <button 
                            onClick={() => setActiveTab('CREATE')}
                            className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'CREATE' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}
                        >
                            <Plus className="w-5 h-5" />
                            <span>Create New</span>
                        </button>
                    </>
                )}
                {role === 'ADMIN' && (
                    <button 
                        onClick={() => setActiveTab('MODERATION')}
                        className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'MODERATION' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}
                    >
                        <AlertCircle className="w-5 h-5" />
                        <span>Moderation Queue</span>
                        {pendingListings.length > 0 && (
                            <span className="ml-auto bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{pendingListings.length}</span>
                        )}
                    </button>
                )}
            </nav>
        </div>
      </aside>

      {/* Content Area */}
      <main className="flex-grow p-8 overflow-y-auto">
        
        {activeTab === 'OVERVIEW' && (
            <div className="max-w-6xl mx-auto animate-fade-in">
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-2xl font-bold text-gray-900">{role === 'ADMIN' ? 'Platform Overview' : 'School Performance'}</h1>
                </div>

                {/* KPI Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-gray-500 text-sm font-medium">Total Revenue</h3>
                            <DollarSign className="w-5 h-5 text-green-500" />
                        </div>
                        <p className="text-3xl font-bold text-gray-900">$124,500</p>
                    </div>
                    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-gray-500 text-sm font-medium">Bookings</h3>
                            <CalendarCheck className="w-5 h-5 text-brand-500" />
                        </div>
                        <p className="text-3xl font-bold text-gray-900">45</p>
                    </div>
                    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-gray-500 text-sm font-medium">Views</h3>
                            <Users className="w-5 h-5 text-purple-500" />
                        </div>
                        <p className="text-3xl font-bold text-gray-900">1,293</p>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-8">
                    <h3 className="font-bold text-gray-800 mb-6">Revenue Overview</h3>
                    <div className="h-72">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={data}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" tick={{fontSize: 12}} axisLine={false} tickLine={false} />
                                <YAxis tick={{fontSize: 12}} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
                                <Tooltip cursor={{fill: '#f3f4f6'}} />
                                <Bar dataKey="revenue" fill="#0ea5e9" radius={[4, 4, 0, 0]} barSize={32} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'CREATE' && (
            <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-sm border border-gray-200 p-8 animate-fade-in">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Create New Listing</h2>
                <form onSubmit={handleCreateListing} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                        <input 
                            type="text" 
                            required
                            value={newListingTitle}
                            onChange={e => setNewListingTitle(e.target.value)}
                            className="w-full border-gray-300 rounded-lg focus:ring-brand-500 focus:border-brand-500"
                            placeholder="e.g., Beginner Surf Class"
                        />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                            <select 
                                value={newListingType}
                                onChange={e => setNewListingType(e.target.value as ListingType)}
                                className="w-full border-gray-300 rounded-lg focus:ring-brand-500"
                            >
                                <option value="ACTIVITY">Activity</option>
                                <option value="RENT">Rental</option>
                                <option value="TRIP">Trip</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                            <select 
                                value={newListingCategory}
                                onChange={e => setNewListingCategory(e.target.value as SportCategory)}
                                className="w-full border-gray-300 rounded-lg focus:ring-brand-500"
                            >
                                <option value="WATER">Water</option>
                                <option value="LAND">Land</option>
                                <option value="SNOW">Snow</option>
                                <option value="AIR">Air</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Price per person ($)</label>
                        <input 
                             type="number" 
                             required
                             value={newListingPrice}
                             onChange={e => setNewListingPrice(Number(e.target.value))}
                             className="w-full border-gray-300 rounded-lg focus:ring-brand-500"
                        />
                    </div>

                    <div className="pt-4">
                        <button type="submit" className="w-full bg-brand-600 text-white py-3 rounded-lg font-bold hover:bg-brand-700 transition-colors">
                            Submit for Review
                        </button>
                    </div>
                </form>
            </div>
        )}

        {activeTab === 'MODERATION' && (
            <div className="max-w-5xl mx-auto animate-fade-in">
                 <h2 className="text-2xl font-bold text-gray-900 mb-6">Pending Approvals</h2>
                 <div className="space-y-4">
                     {pendingListings.length === 0 ? (
                         <p className="text-gray-500">No listings pending approval.</p>
                     ) : (
                         pendingListings.map(l => (
                             <div key={l.id} className="bg-white p-6 rounded-xl border border-gray-200 flex items-center justify-between">
                                 <div className="flex items-center space-x-4">
                                     <div className="w-16 h-16 bg-gray-200 rounded-lg overflow-hidden">
                                         <img src={l.images[0]} className="w-full h-full object-cover" alt="thumb" />
                                     </div>
                                     <div>
                                         <h3 className="font-bold text-gray-900">{l.title}</h3>
                                         <p className="text-sm text-gray-500">{l.providerName} • {l.location.city}, {l.location.country}</p>
                                     </div>
                                 </div>
                                 <div className="flex space-x-2">
                                     <button className="p-2 rounded-full bg-red-50 text-red-600 hover:bg-red-100">
                                         <X className="w-5 h-5" />
                                     </button>
                                     <button 
                                        onClick={() => handleApprove(l.id)}
                                        className="p-2 rounded-full bg-green-50 text-green-600 hover:bg-green-100"
                                    >
                                         <Check className="w-5 h-5" />
                                     </button>
                                 </div>
                             </div>
                         ))
                     )}
                 </div>
            </div>
        )}

      </main>
    </div>
  );
};

export default Dashboard;
