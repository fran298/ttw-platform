
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Globe, ArrowRight, Check } from 'lucide-react';

// Temporary until backend is wired. Replace with real API call.
const preRegisterProvider = async (data: { company: string; city: string; email: string }) => {
  // Example: await api.post('/auth/provider/pre-register', data)
  console.log('preRegisterProvider payload', data);
  return true;
};

const SignupProvider: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ company: '', city: '', email: '' });

  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      // Call pre-register mock
      await preRegisterProvider(formData);
      // Redirect to full onboarding
      navigate('/onboarding');
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col relative overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
             <img 
                src="https://images.unsplash.com/photo-1551632811-561732d1e306?q=80&w=2070&auto=format&fit=crop" 
                alt="Adventure" 
                className="w-full h-full object-cover opacity-30" 
             />
        </div>

        {/* Content */}
        <div className="relative z-10 flex-grow flex flex-col justify-center items-center px-4">
             <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                 
                 {/* Left Side: Copy */}
                 <div className="text-white">
                     <div className="flex items-center mb-6">
                        <div className="bg-brand-600 text-white p-1.5 rounded-full mr-2">
                            <Globe className="w-6 h-6" />
                        </div>
                        <span className="text-xl font-black uppercase">The Travel Wild</span>
                     </div>
                     <h1 className="text-4xl md:text-5xl font-black leading-tight mb-6">
                         Grow your <br/>
                         <span className="text-brand-500">Wild Business</span> <br/>
                         with us.
                     </h1>
                     <ul className="space-y-4 text-gray-300 mb-8">
                         <li className="flex items-center"><Check className="w-5 h-5 text-green-400 mr-2"/> Reach global travelers instantly</li>
                         <li className="flex items-center"><Check className="w-5 h-5 text-green-400 mr-2"/> Secure payments via Stripe</li>
                         <li className="flex items-center"><Check className="w-5 h-5 text-green-400 mr-2"/> Manage bookings & rentals easily</li>
                     </ul>
                 </div>

                 {/* Right Side: Form */}
                 <div className="bg-white rounded-2xl shadow-2xl p-8">
                     <h2 className="text-2xl font-bold text-gray-900 mb-2">Get Started</h2>
                     <p className="text-gray-500 text-sm mb-6">Join thousands of schools and guides. No credit card required.</p>
                     
                     <form onSubmit={handleSubmit} className="space-y-4">
                         <div>
                             <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Company / School Name</label>
                             <input 
                                type="text" 
                                required
                                value={formData.company}
                                onChange={e => setFormData({...formData, company: e.target.value})}
                                className="w-full border-gray-300 rounded-lg" 
                                placeholder="e.g. Tarifa Kite School" 
                             />
                         </div>
                         <div>
                             <label className="block text-xs font-bold text-gray-700 uppercase mb-1">City & Country</label>
                             <input 
                                type="text" 
                                required
                                value={formData.city}
                                onChange={e => setFormData({...formData, city: e.target.value})}
                                className="w-full border-gray-300 rounded-lg" 
                                placeholder="e.g. Tarifa, Spain" 
                             />
                         </div>
                         <div>
                             <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Business Email</label>
                             <input 
                                type="email" 
                                required
                                value={formData.email}
                                onChange={e => setFormData({...formData, email: e.target.value})}
                                className="w-full border-gray-300 rounded-lg" 
                                placeholder="info@school.com" 
                             />
                         </div>
                         
                         <button type="submit" className="w-full bg-brand-600 text-white py-3 rounded-lg font-bold hover:bg-brand-700 transition-colors flex justify-center items-center">
                             Continue Setup <ArrowRight className="w-4 h-4 ml-2" />
                         </button>
                     </form>
                 </div>

             </div>
        </div>
    </div>
  );
};

export default SignupProvider;
