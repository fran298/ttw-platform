
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getSportLandingDetails, SportLandingData, getListings, getTopSchoolsForSport } from '../services/dataService';
import { Listing, ProviderProfile } from '../types';
import ListingCard from '../components/ListingCard';
import { MapPin, DollarSign, Layers, ArrowRight, Activity, ShieldCheck, Star } from 'lucide-react';

const SportLanding: React.FC = () => {
  const { sportSlug } = useParams<{ sportSlug: string }>();
  const [data, setData] = useState<SportLandingData | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [schools, setSchools] = useState<ProviderProfile[]>([]);
  const [loading, setLoading] = useState(true);

  // Formatting name for display
  const displaySport = data?.name || sportSlug;

  useEffect(() => {
    const fetch = async () => {
      if (sportSlug) {
        setLoading(true);
        const sportData = await getSportLandingDetails(sportSlug);
        setData(sportData);
        
        // Fetch top schools (premium partners)
        const topSchools = await getTopSchoolsForSport(sportSlug);
        setSchools(topSchools);

        // Fetch specific listings
        const sportListings = await getListings({ sport: sportSlug });
        setListings(sportListings);
        setLoading(false);
      }
    };
    fetch();
  }, [sportSlug]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white">Loading Sport Data...</div>;
  if (!data) return <div className="min-h-screen flex items-center justify-center">Sport not found.</div>;

  return (
    <div className="min-h-screen bg-white font-sans">
      
      {/* 1. IMMERSIVE HERO */}
      <div className="relative h-[70vh] w-full overflow-hidden bg-gray-900">
        <img 
            src={data.heroImage} 
            alt={data.name} 
            className="w-full h-full object-cover opacity-70 scale-105 animate-pulse-slow" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30"></div>
        
        <div className="absolute inset-0 flex flex-col justify-center px-4 md:px-20 max-w-7xl mx-auto">
            <span className="text-brand-400 font-bold tracking-widest uppercase text-sm mb-4 border border-brand-400/30 px-3 py-1 rounded-full w-fit backdrop-blur-sm">
                {data.category} Discipline
            </span>
            <h1 className="text-6xl md:text-8xl font-black text-white mb-6 uppercase tracking-tighter drop-shadow-2xl">
                {data.name}
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 font-light max-w-2xl leading-relaxed mb-8">
                {data.description}
            </p>
            
            <div className="flex flex-wrap gap-8 text-white/80">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/10 rounded-full backdrop-blur"><Layers className="w-5 h-5 text-brand-400"/></div>
                    <div>
                        <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Listings</p>
                        <p className="font-bold text-xl">{data.stats.listingCount}+</p>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/10 rounded-full backdrop-blur"><DollarSign className="w-5 h-5 text-brand-400"/></div>
                    <div>
                         <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Avg Price</p>
                         <p className="font-bold text-xl">${data.stats.avgPrice}</p>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* 2. TOP DESTINATIONS */}
        <div className="mb-20">
            <h2 className="text-3xl font-black text-gray-900 mb-8">Top {data.name} Destinations</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {data.topDestinations.map((dest) => (
                    <Link 
                        key={dest.name} 
                        to={`/destination/${dest.name.toLowerCase()}`}
                        className="group relative h-80 rounded-2xl overflow-hidden cursor-pointer"
                    >
                        <img src={dest.image} alt={dest.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-90"></div>
                        <div className="absolute bottom-6 left-6 text-white">
                            <h3 className="text-3xl font-bold mb-1">{dest.name}</h3>
                            <div className="flex items-center text-sm font-medium text-brand-300">
                                <MapPin className="w-4 h-4 mr-1" /> {dest.count} Active Spots
                            </div>
                        </div>
                        <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-white border border-white/30">
                            {dest.continent}
                        </div>
                    </Link>
                ))}
            </div>
        </div>

        {/* 3. TOP RATED SCHOOLS (Carousel) */}
        <div className="mb-20">
            <h2 className="text-3xl font-black text-gray-900 mb-8">Top Rated {data.name} Schools</h2>
            <div className="flex overflow-x-auto gap-6 pb-4 scrollbar-hide snap-x">
                {schools.map(school => (
                    <Link to={`/provider/${school.id}`} key={school.id} className="min-w-[280px] bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-lg transition-all snap-center group">
                        <div className="flex items-center gap-4 mb-4">
                            <img src={school.logo} alt={school.name} className="w-16 h-16 rounded-full object-cover border border-gray-100" />
                            <div>
                                <h3 className="font-bold text-gray-900 leading-tight group-hover:text-brand-600 transition-colors">{school.name}</h3>
                                <div className="flex items-center text-xs text-gray-500 mt-1">
                                    <MapPin className="w-3 h-3 mr-1" /> {school.location}
                                </div>
                            </div>
                        </div>
                        {school.isVerified && (
                            <div className="inline-flex items-center px-2 py-1 rounded bg-blue-50 text-blue-700 text-xs font-bold mb-4">
                                <ShieldCheck className="w-3 h-3 mr-1" /> Verified Partner
                            </div>
                        )}
                        <div className="flex justify-between items-center text-sm border-t border-gray-100 pt-4">
                            <div className="flex items-center font-bold text-gray-900">
                                 <Star className="w-4 h-4 text-yellow-400 fill-yellow-400 mr-1" /> 4.9
                            </div>
                            <span className="text-brand-600 font-bold text-xs flex items-center">
                                View Profile <ArrowRight className="w-3 h-3 ml-1" />
                            </span>
                        </div>
                    </Link>
                ))}
            </div>
        </div>

        {/* 4. ACTIVE LISTINGS */}
        <div>
            <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-black text-gray-900">Book {data.name}</h2>
                <Link to={`/explore?sport=${data.name}`} className="bg-gray-900 text-white px-6 py-3 rounded-full font-bold text-sm hover:bg-black transition-colors flex items-center">
                    View All {listings.length} Listings <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {listings.slice(0, 4).map(l => (
                    <ListingCard key={l.id} listing={l} />
                ))}
            </div>
            
            {listings.length === 0 && (
                <div className="text-center py-20 bg-gray-50 rounded-2xl border border-dashed border-gray-300">
                    <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-bold text-gray-900">No {data.name} listings yet</h3>
                    <p className="text-gray-500">Check back later or explore other sports.</p>
                </div>
            )}
        </div>

      </div>
    </div>
  );
};

export default SportLanding;
