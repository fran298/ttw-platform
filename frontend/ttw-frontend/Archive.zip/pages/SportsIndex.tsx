
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getSportsDirectory } from '../services/dataService';
import { SportDirectoryItem, SportCategory } from '../types';
import { CATEGORY_ICONS } from '../constants';
import { ArrowRight, Waves, Mountain, Snowflake, Wind } from 'lucide-react';

const SportsIndex: React.FC = () => {
  const [sports, setSports] = useState<SportDirectoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<SportCategory | 'ALL'>('ALL');

  useEffect(() => {
    const fetch = async () => {
      const data = await getSportsDirectory();
      setSports(data);
      setLoading(false);
    };
    fetch();
  }, []);

  const filteredSports = activeCategory === 'ALL' 
    ? sports 
    : sports.filter(s => s.category === activeCategory);

  const getCategoryIcon = (cat: SportCategory) => {
      switch(cat) {
          case SportCategory.WATER: return <Waves className="w-5 h-5" />;
          case SportCategory.LAND: return <Mountain className="w-5 h-5" />;
          case SportCategory.SNOW: return <Snowflake className="w-5 h-5" />;
          case SportCategory.AIR: return <Wind className="w-5 h-5" />;
          default: return null;
      }
  };

  return (
    <div className="min-h-screen bg-white font-sans">
      
      {/* HERO SECTION */}
      <div className="relative h-[50vh] bg-gray-900 flex items-center justify-center overflow-hidden">
         <img 
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1600&q=80" 
            alt="Action Sports" 
            className="absolute inset-0 w-full h-full object-cover opacity-60"
         />
         <div className="relative z-10 text-center px-4">
            <h1 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter mb-4 drop-shadow-xl">
                Choose Your Element
            </h1>
            <p className="text-xl text-gray-200 font-light max-w-2xl mx-auto">
                Explore our directory of extreme sports. From the peaks to the ocean depths, find where you belong.
            </p>
         </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* ELEMENT TABS */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
            <button
                onClick={() => setActiveCategory('ALL')}
                className={`px-8 py-3 rounded-full font-bold text-sm tracking-wide transition-all ${
                    activeCategory === 'ALL'
                    ? 'bg-gray-900 text-white shadow-lg scale-105'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
            >
                ALL
            </button>
            {Object.values(SportCategory).map((cat) => (
                <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`flex items-center gap-2 px-8 py-3 rounded-full font-bold text-sm tracking-wide transition-all ${
                        activeCategory === cat
                        ? 'bg-brand-600 text-white shadow-lg scale-105'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                >
                    {getCategoryIcon(cat)}
                    {cat}
                </button>
            ))}
        </div>

        {/* SPORTS GRID */}
        {loading ? (
            <div className="flex justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredSports.map((sport) => (
                    <div key={sport.slug} className="group relative h-[400px] rounded-3xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-500">
                        {/* Background Image */}
                        <img 
                            src={sport.image} 
                            alt={sport.name} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
                        
                        {/* Top Badge */}
                        <div className="absolute top-6 left-6 flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
                            <span className="text-white text-xs font-bold uppercase tracking-wider">{sport.category}</span>
                        </div>

                        {/* Content */}
                        <div className="absolute bottom-0 left-0 w-full p-8 text-white">
                            <h3 className="text-4xl font-black uppercase mb-3 leading-none">{sport.name}</h3>
                            <p className="text-gray-300 text-sm line-clamp-2 mb-6 opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                                {sport.description}
                            </p>
                            
                            <div className="flex items-center justify-between border-t border-white/20 pt-4">
                                <span className="text-sm font-medium text-gray-400">{sport.listingCount} Listings</span>
                                <Link 
                                    to={`/sport/${sport.slug}`}
                                    className="flex items-center text-brand-400 font-bold text-sm uppercase tracking-wider hover:text-white transition-colors"
                                >
                                    Explore <ArrowRight className="w-4 h-4 ml-2" />
                                </Link>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        )}
      </div>
    </div>
  );
};

export default SportsIndex;