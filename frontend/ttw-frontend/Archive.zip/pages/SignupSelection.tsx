
import React from 'react';
import { Link } from 'react-router-dom';
import { User, Briefcase, ChevronRight, Globe } from 'lucide-react';

const SignupSelection: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
      <Link to="/" className="flex items-center group mb-12">
        <div className="bg-brand-600 text-white p-2 rounded-full mr-2">
            <Globe className="w-8 h-8" />
        </div>
        <div className="flex flex-col leading-none">
            <span className="text-2xl font-black tracking-tight text-gray-800 uppercase">The Travel</span>
            <span className="text-2xl font-black tracking-tight text-brand-600 uppercase -mt-1">Wild</span>
        </div>
      </Link>

      <h1 className="text-3xl md:text-4xl font-black text-gray-900 mb-8 text-center">How do you want to join?</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl w-full">
        
        {/* User Card */}
        <Link to="/signup/user" className="group relative bg-white rounded-2xl shadow-lg border-2 border-transparent hover:border-brand-500 transition-all p-8 flex flex-col items-center text-center overflow-hidden">
           <div className="absolute inset-0 bg-brand-50 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
           <div className="relative z-10">
               <div className="w-20 h-20 bg-blue-100 text-brand-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                   <User className="w-10 h-10" />
               </div>
               <h2 className="text-2xl font-bold text-gray-900 mb-2">I am a Traveler</h2>
               <p className="text-gray-500 mb-6">Book adventures, rent equipment, and join trips around the world.</p>
               <span className="inline-flex items-center text-brand-600 font-bold">
                   Create User Account <ChevronRight className="w-4 h-4 ml-1" />
               </span>
           </div>
        </Link>

        {/* Provider Card */}
        <Link to="/signup/provider" className="group relative bg-white rounded-2xl shadow-lg border-2 border-transparent hover:border-brand-500 transition-all p-8 flex flex-col items-center text-center overflow-hidden">
           <div className="absolute inset-0 bg-brand-50 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
           <div className="relative z-10">
               <div className="w-20 h-20 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                   <Briefcase className="w-10 h-10" />
               </div>
               <h2 className="text-2xl font-bold text-gray-900 mb-2">I am a Provider</h2>
               <p className="text-gray-500 mb-6">List your school, tours, or equipment rentals and reach global customers.</p>
               <span className="inline-flex items-center text-orange-600 font-bold">
                   Become a Partner <ChevronRight className="w-4 h-4 ml-1" />
               </span>
           </div>
        </Link>

      </div>

      <p className="mt-8 text-gray-500 text-sm">
        Already have an account? <Link to="/login" className="text-brand-600 font-bold hover:underline">Log in</Link>
      </p>
    </div>
  );
};

export default SignupSelection;
