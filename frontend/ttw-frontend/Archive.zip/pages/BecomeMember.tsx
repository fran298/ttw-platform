
import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, TrendingUp, Users, Calendar, Shield, DollarSign, ArrowRight, LayoutDashboard, Globe, MousePointerClick, Image, Rocket, Sparkles, UserCheck, Star, Award, ShieldCheck } from 'lucide-react';

const BecomeMember: React.FC = () => {
  
  const scrollToHowItWorks = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById('how-it-works');
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-white min-h-screen font-sans">
      
      {/* 1. HERO SECTION */}
      <div className="relative overflow-hidden bg-gray-900 pt-20 pb-24 lg:pt-32 lg:pb-40">
        <img 
            src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=2000&q=80" 
            alt="Team working" 
            className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900/90 via-gray-900/80 to-gray-900"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="inline-block py-1 px-3 rounded-full bg-brand-500/20 text-brand-300 border border-brand-500/30 text-xs font-bold uppercase tracking-widest mb-6">
                For Schools, Instructors & Guides
            </span>
            <h1 className="text-5xl md:text-7xl font-black text-white tracking-tight mb-8 leading-tight">
                Turn your passion into a <br/>
                <span className="text-brand-500">Global Business</span>.
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-10 leading-relaxed">
                The all-in-one platform to manage bookings, payments, and marketing. 
                Stop chasing emails and start filling your calendar.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link 
                    to="/signup/provider" 
                    className="bg-brand-600 hover:bg-brand-500 text-white px-8 py-4 rounded-full font-bold text-lg transition-all shadow-lg shadow-brand-900/50 flex items-center justify-center"
                >
                    List Your Business for Free <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
                <button 
                    onClick={scrollToHowItWorks}
                    className="bg-white/10 hover:bg-white/20 backdrop-blur text-white border border-white/20 px-8 py-4 rounded-full font-bold text-lg transition-all flex items-center justify-center"
                >
                    See How It Works
                </button>
            </div>
            <p className="mt-6 text-sm text-gray-500">No credit card required • Cancel anytime</p>
        </div>
      </div>

      {/* 2. SOCIAL PROOF / STATS */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <p className="text-center text-sm font-bold text-gray-400 uppercase tracking-widest mb-8">Trusted by 500+ Adventure Companies</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div>
                    <div className="text-4xl font-black text-gray-900 mb-1">2.5x</div>
                    <div className="text-sm text-gray-500 font-medium">Booking Increase</div>
                </div>
                <div>
                    <div className="text-4xl font-black text-gray-900 mb-1">150+</div>
                    <div className="text-sm text-gray-500 font-medium">Countries Reached</div>
                </div>
                <div>
                    <div className="text-4xl font-black text-gray-900 mb-1">$10M+</div>
                    <div className="text-sm text-gray-500 font-medium">Partner Revenue</div>
                </div>
                <div>
                    <div className="text-4xl font-black text-gray-900 mb-1">0%</div>
                    <div className="text-sm text-gray-500 font-medium">Upfront Costs</div>
                </div>
            </div>
        </div>
      </div>

      {/* NEW SECTION: HOW IT WORKS */}
      <div id="how-it-works" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                  <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-4">How it works</h2>
                  <p className="text-lg text-gray-600 max-w-2xl mx-auto">Getting started is simple. We handle the tech so you can focus on teaching.</p>
              </div>

              <div className="relative grid grid-cols-1 md:grid-cols-3 gap-12">
                  {/* Connecting Line (Desktop only) */}
                  <div className="hidden md:block absolute top-12 left-1/6 right-1/6 h-0.5 bg-gray-100 -z-10"></div>

                  {/* Step 1 */}
                  <div className="flex flex-col items-center text-center">
                      <div className="w-24 h-24 bg-brand-50 rounded-full flex items-center justify-center mb-6 border-4 border-white shadow-lg">
                          <MousePointerClick className="w-10 h-10 text-brand-600" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">1. Create Profile</h3>
                      <p className="text-gray-500 leading-relaxed">
                          Sign up in 2 minutes. Add your logo, location, and connect your bank account via Stripe for secure payouts.
                      </p>
                  </div>

                  {/* Step 2 */}
                  <div className="flex flex-col items-center text-center">
                      <div className="w-24 h-24 bg-brand-50 rounded-full flex items-center justify-center mb-6 border-4 border-white shadow-lg">
                          <Image className="w-10 h-10 text-brand-600" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">2. List Activities</h3>
                      <p className="text-gray-500 leading-relaxed">
                          Upload photos, set prices, and manage your calendar. Whether it's rentals, lessons, or multi-day trips.
                      </p>
                  </div>

                  {/* Step 3 */}
                  <div className="flex flex-col items-center text-center">
                      <div className="w-24 h-24 bg-brand-50 rounded-full flex items-center justify-center mb-6 border-4 border-white shadow-lg">
                          <Rocket className="w-10 h-10 text-brand-600" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">3. Go Live</h3>
                      <p className="text-gray-500 leading-relaxed">
                          Your listings appear instantly on our global marketplace. Receive bookings and get paid automatically.
                      </p>
                  </div>
              </div>
          </div>
      </div>

      {/* 3. VALUE PROPOSITION GRID */}
      <div className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-3xl mx-auto mb-16">
                  <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-4">Everything you need to run your school</h2>
                  <p className="text-lg text-gray-600">We don't just send you leads. We provide the complete infrastructure to manage your extreme sports business.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                  {/* Card 1 */}
                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                      <div className="w-14 h-14 bg-blue-100 text-brand-600 rounded-xl flex items-center justify-center mb-6">
                          <Globe className="w-8 h-8" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">Global Visibility</h3>
                      <p className="text-gray-600 leading-relaxed">
                          Your activities appear automatically on our city, country, and sport-specific landing pages. Reach travelers before they even arrive.
                      </p>
                  </div>

                  {/* Card 2 */}
                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                      <div className="w-14 h-14 bg-green-100 text-green-600 rounded-xl flex items-center justify-center mb-6">
                          <DollarSign className="w-8 h-8" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">Seamless Payments</h3>
                      <p className="text-gray-600 leading-relaxed">
                          Integrated with Stripe Connect. Get paid directly to your bank account. Handle deposits, refunds, and multi-currency easily.
                      </p>
                  </div>

                  {/* Card 3 */}
                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                      <div className="w-14 h-14 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center mb-6">
                          <LayoutDashboard className="w-8 h-8" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">Mission Control</h3>
                      <p className="text-gray-600 leading-relaxed">
                          A powerful dashboard to manage instructors, inventory (rentals), calendar availability, and messages in one place.
                      </p>
                  </div>
              </div>
          </div>
      </div>

      {/* NEW SECTION: THE FREELANCE INSTRUCTOR REVOLUTION */}
      <div className="py-24 bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col md:flex-row items-center gap-12 lg:gap-24">
                  {/* Image/Visual Side */}
                  <div className="w-full md:w-1/2 order-2 md:order-1 relative">
                       {/* Abstract Background Blob */}
                       <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-tr from-orange-100 to-pink-50 rounded-full blur-3xl opacity-60"></div>
                       
                       {/* Profile Card Mockup */}
                       <div className="relative bg-white rounded-3xl p-6 shadow-2xl border border-gray-100 transform rotate-[-2deg] hover:rotate-0 transition-all duration-500 max-w-sm mx-auto">
                           <div className="flex items-center gap-4 mb-6">
                               <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80" alt="Instructor" className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-md" />
                               <div>
                                   <div className="flex items-center gap-2 mb-1">
                                       <h3 className="text-xl font-black text-gray-900">Sarah Jenkins</h3>
                                       <ShieldCheck className="w-5 h-5 text-blue-500" />
                                   </div>
                                   <p className="text-sm font-bold text-gray-500 uppercase tracking-wide">Kitesurf Pro • Tarifa</p>
                                   <div className="flex text-yellow-400 mt-1">
                                       <Star className="w-4 h-4 fill-current" />
                                       <Star className="w-4 h-4 fill-current" />
                                       <Star className="w-4 h-4 fill-current" />
                                       <Star className="w-4 h-4 fill-current" />
                                       <Star className="w-4 h-4 fill-current" />
                                       <span className="text-gray-400 text-xs ml-2 font-medium">(48 Reviews)</span>
                                   </div>
                               </div>
                           </div>
                           <div className="space-y-3 mb-6">
                               <div className="bg-gray-50 rounded-lg p-3 flex justify-between items-center">
                                   <span className="text-sm font-bold text-gray-600">Private Lesson</span>
                                   <span className="text-sm font-bold text-gray-900">$80/hr</span>
                               </div>
                               <div className="bg-gray-50 rounded-lg p-3 flex justify-between items-center">
                                   <span className="text-sm font-bold text-gray-600">Full Gear Rental</span>
                                   <span className="text-sm font-bold text-gray-900">$120/day</span>
                               </div>
                           </div>
                           <button className="w-full bg-black text-white py-3 rounded-xl font-bold text-sm">Book with Sarah</button>
                       </div>
                  </div>

                  {/* Content Side */}
                  <div className="w-full md:w-1/2 order-1 md:order-2">
                      <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-800 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-6">
                          <UserCheck className="w-4 h-4" /> For Freelancers
                      </div>
                      <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-6 leading-tight">
                          The only platform built for <span className="text-orange-500">Instructors</span>.
                      </h2>
                      <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                          Tired of being invisible behind a school's logo? We are the first platform in the extreme sports world that allows you to build your own personal brand.
                      </p>
                      
                      <div className="space-y-6 mb-10">
                          <div className="flex items-start">
                              <div className="bg-orange-100 p-2 rounded-lg mr-4 mt-1">
                                  <Award className="w-6 h-6 text-orange-600" />
                              </div>
                              <div>
                                  <h4 className="text-lg font-bold text-gray-900">Build Your Reputation</h4>
                                  <p className="text-gray-500">Collect reviews directly on your personal profile. Your reputation travels with you, wherever you teach.</p>
                              </div>
                          </div>
                          <div className="flex items-start">
                              <div className="bg-orange-100 p-2 rounded-lg mr-4 mt-1">
                                  <TrendingUp className="w-6 h-6 text-orange-600" />
                              </div>
                              <div>
                                  <h4 className="text-lg font-bold text-gray-900">Grow as a Freelancer</h4>
                                  <p className="text-gray-500">Set your own prices, manage your own schedule, and keep more of what you earn. Be your own boss.</p>
                              </div>
                          </div>
                      </div>

                      <Link to="/signup/provider" className="text-orange-600 font-bold text-lg hover:text-orange-700 flex items-center group">
                          Create Instructor Profile <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </Link>
                  </div>
              </div>
          </div>
      </div>

      {/* 4. DASHBOARD PREVIEW SECTION */}
      <div className="py-24 bg-gray-50 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row items-center gap-16">
              <div className="lg:w-1/2">
                  <span className="text-brand-600 font-bold uppercase tracking-widest text-sm mb-2 block">Built for Pros</span>
                  <h2 className="text-4xl font-black text-gray-900 mb-6">Stop using spreadsheets.<br/>Start using TTW.</h2>
                  <div className="space-y-6">
                      <div className="flex">
                          <div className="flex-shrink-0 mt-1">
                              <CheckCircle className="w-6 h-6 text-green-500" />
                          </div>
                          <div className="ml-4">
                              <h4 className="text-lg font-bold text-gray-900">Real-time Availability</h4>
                              <p className="text-gray-600">Prevent double bookings with our smart calendar that syncs with your inventory.</p>
                          </div>
                      </div>
                      <div className="flex">
                          <div className="flex-shrink-0 mt-1">
                              <CheckCircle className="w-6 h-6 text-green-500" />
                          </div>
                          <div className="ml-4">
                              <h4 className="text-lg font-bold text-gray-900">Instructor Management</h4>
                              <p className="text-gray-600">Assign specific instructors to trips and let them see their own schedules.</p>
                          </div>
                      </div>
                      <div className="flex">
                          <div className="flex-shrink-0 mt-1">
                              <CheckCircle className="w-6 h-6 text-green-500" />
                          </div>
                          <div className="ml-4">
                              <h4 className="text-lg font-bold text-gray-900">Automated Messaging</h4>
                              <p className="text-gray-600">Send automatic meeting points, packing lists, and weather updates to your students.</p>
                          </div>
                      </div>
                  </div>
                  <div className="mt-10">
                      <Link to="/signup/provider" className="text-brand-600 font-bold text-lg hover:underline flex items-center">
                          Explore the Dashboard <ArrowRight className="ml-2 w-5 h-5"/>
                      </Link>
                  </div>
              </div>
              
              <div className="lg:w-1/2 relative">
                  {/* Abstract Dashboard Visual */}
                  <div className="relative rounded-2xl shadow-2xl border border-gray-200 overflow-hidden bg-gray-50 transform rotate-1 hover:rotate-0 transition-transform duration-700">
                       <img 
                           src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80" 
                           alt="Dashboard Preview" 
                           className="w-full object-cover"
                       />
                       {/* Floating Cards Overlay */}
                       <div className="absolute top-8 right-8 bg-white p-4 rounded-lg shadow-xl border border-gray-100 max-w-xs animate-pulse-slow">
                           <div className="flex items-center gap-3 mb-2">
                               <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600"><DollarSign className="w-5 h-5"/></div>
                               <div>
                                   <div className="text-xs text-gray-500">New Booking</div>
                                   <div className="font-bold text-gray-900">+$450.00</div>
                               </div>
                           </div>
                       </div>
                  </div>
              </div>
          </div>
      </div>

      {/* 5. PRICING & MEMBERSHIP TIERS */}
      <div className="py-24 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-black mb-6">Choose your Growth Path</h2>
            <p className="text-xl text-gray-400">
                Start for free or accelerate your business with our Premium Membership.
            </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            
            {/* STARTER PLAN */}
            <div className="bg-gray-800 rounded-3xl p-8 border border-gray-700 flex flex-col">
                <div className="mb-8">
                <h3 className="text-2xl font-bold text-white">Starter Partner</h3>
                <p className="text-gray-400 mt-2">Perfect for new schools and independent instructors.</p>
                </div>
                <div className="mb-8">
                <span className="text-5xl font-black text-white">€0</span>
                <span className="text-gray-400 text-lg"> / year</span>
                <div className="mt-4 inline-block bg-gray-700 px-4 py-1 rounded-full text-sm font-bold text-gray-300">
                    25% Commission
                </div>
                </div>
                <ul className="space-y-4 mb-8 flex-1">
                <li className="flex items-start"><CheckCircle className="w-5 h-5 text-gray-500 mr-3 mt-0.5"/> Standard Listing Visibility</li>
                <li className="flex items-start"><CheckCircle className="w-5 h-5 text-gray-500 mr-3 mt-0.5"/> Booking Management Dashboard</li>
                <li className="flex items-start"><CheckCircle className="w-5 h-5 text-gray-500 mr-3 mt-0.5"/> Secure Stripe Payments</li>
                <li className="flex items-start"><CheckCircle className="w-5 h-5 text-gray-500 mr-3 mt-0.5"/> Basic Support</li>
                </ul>
                <Link to="/signup/provider" className="w-full block text-center bg-gray-700 hover:bg-gray-600 text-white py-4 rounded-xl font-bold transition-colors">
                Start for Free
                </Link>
            </div>

            {/* PREMIUM PLAN */}
            <div className="bg-white text-gray-900 rounded-3xl p-8 border-4 border-brand-500 relative flex flex-col transform md:-translate-y-4 shadow-2xl shadow-brand-900/50">
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-brand-600 text-white px-6 py-2 rounded-full font-bold text-sm tracking-widest uppercase shadow-lg">
                Most Popular
                </div>
                <div className="mb-8 pt-4">
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-2xl font-bold text-gray-900">Premium Partner</h3>
                        <p className="text-gray-500 mt-2">For established schools scaling their operations.</p>
                    </div>
                    <div className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-xs font-bold flex items-center">
                        <Sparkles className="w-3 h-3 mr-1" /> Best Value
                    </div>
                </div>
                </div>
                <div className="mb-8">
                <div className="flex items-baseline gap-2">
                    <span className="text-5xl font-black text-gray-900">€499</span>
                    <span className="text-gray-500 text-lg"> / year</span>
                </div>
                <p className="text-red-500 font-bold text-sm mt-2 uppercase tracking-wide animate-pulse">
                    Limited Time Offer
                </p>
                
                <div className="mt-4 inline-block bg-green-100 text-green-800 px-4 py-1 rounded-full text-sm font-bold border border-green-200">
                    15% Commission (Save 10%)
                </div>
                <p className="text-xs text-green-600 mt-2 font-medium">
                   *Break even after just €5k in bookings.
                </p>
                </div>
                <ul className="space-y-4 mb-8 flex-1">
                <li className="flex items-start">
                    <div className="bg-brand-100 p-1 rounded-full mr-3 mt-0.5"><CheckCircle className="w-4 h-4 text-brand-600"/></div>
                    <span className="font-bold">Verified Partner Badge (Trust Boost)</span>
                </li>
                <li className="flex items-start">
                    <div className="bg-brand-100 p-1 rounded-full mr-3 mt-0.5"><CheckCircle className="w-4 h-4 text-brand-600"/></div>
                    <span><span className="font-bold">Featured Placement</span> in Top Schools Carousel</span>
                </li>
                <li className="flex items-start">
                    <div className="bg-brand-100 p-1 rounded-full mr-3 mt-0.5"><CheckCircle className="w-4 h-4 text-brand-600"/></div>
                    <span><span className="font-bold">Google Ads</span> & Search Boost included</span>
                </li>
                <li className="flex items-start">
                    <div className="bg-brand-100 p-1 rounded-full mr-3 mt-0.5"><CheckCircle className="w-4 h-4 text-brand-600"/></div>
                    <span>Competitor Insights & Advanced Analytics</span>
                </li>
                <li className="flex items-start">
                    <div className="bg-brand-100 p-1 rounded-full mr-3 mt-0.5"><CheckCircle className="w-4 h-4 text-brand-600"/></div>
                    <span>Priority 24/7 Support</span>
                </li>
                </ul>
                <Link to="/signup/provider?plan=premium" className="w-full block text-center bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-xl font-bold transition-colors shadow-lg">
                Become a Premium Partner
                </Link>
            </div>

            </div>
        </div>
      </div>

      {/* 6. FAQ SECTION */}
      <div className="py-24 bg-gray-50">
          <div className="max-w-3xl mx-auto px-4">
              <h2 className="text-3xl font-black text-gray-900 text-center mb-12">Frequently Asked Questions</h2>
              <div className="space-y-6">
                  {[
                      { q: "How do I get paid?", a: "We use Stripe Connect. Funds are transferred to your bank account automatically after the activity is completed, minus our commission." },
                      { q: "Can I sync with my Google Calendar?", a: "Yes! Our dashboard has a 2-way sync with Google Calendar, iCal, and other booking systems to prevent double bookings." },
                      { q: "What kind of activities can I list?", a: "We specialize in extreme sports: Surfing, Kitesurfing, Skiing, Climbing, Diving, etc. Lessons, rentals, and multi-day trips are all welcome." },
                      { q: "Is there a verification process?", a: "Yes. To maintain quality, we verify all partners. You'll need to upload business documents or certifications during onboarding." }
                  ].map((item, i) => (
                      <div key={i} className="bg-white p-6 rounded-xl border border-gray-200">
                          <h4 className="font-bold text-gray-900 text-lg mb-2">{item.q}</h4>
                          <p className="text-gray-600">{item.a}</p>
                      </div>
                  ))}
              </div>
          </div>
      </div>

      {/* 7. FINAL CTA */}
      <div className="bg-brand-600 py-20">
          <div className="max-w-4xl mx-auto px-4 text-center text-white">
              <h2 className="text-4xl font-black mb-6">Ready to grow your wild business?</h2>
              <p className="text-xl text-brand-100 mb-10">Join the world's fastest-growing extreme sports marketplace today.</p>
              <Link to="/signup/provider" className="bg-white text-brand-600 px-10 py-5 rounded-full font-bold text-xl hover:bg-gray-100 transition-colors shadow-2xl inline-flex items-center">
                  Start Your Journey <ArrowRight className="ml-2 w-6 h-6" />
              </Link>
          </div>
      </div>
    </div>
  );
};

export default BecomeMember;
